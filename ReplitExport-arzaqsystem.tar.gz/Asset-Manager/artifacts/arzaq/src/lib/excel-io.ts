import * as XLSX from "xlsx";
import type { Sale } from "./store";

/**
 * Each row written: التاريخ | الوقت | المنتج | الشركة | الكمية | العمولة الإجمالية
 */
export function exportSalesToExcel(
  sales: Sale[],
  username: string | null,
): void {
  const sorted = sales
    .slice()
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const data = sorted.map((s) => {
    const d = new Date(s.date);
    const pad = (n: number) => n.toString().padStart(2, "0");
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    return {
      التاريخ: date,
      الوقت: time,
      المنتج: s.productName,
      الشركة: s.company || "",
      الكمية: s.quantity ?? 1,
      "العمولة الإجمالية (د.ل)": Number(s.commission.toFixed(2)),
    };
  });

  const ws = XLSX.utils.json_to_sheet(data, {
    header: [
      "التاريخ",
      "الوقت",
      "المنتج",
      "الشركة",
      "الكمية",
      "العمولة الإجمالية (د.ل)",
    ],
  });

  // Set column widths
  ws["!cols"] = [
    { wch: 12 },
    { wch: 10 },
    { wch: 22 },
    { wch: 14 },
    { wch: 8 },
    { wch: 22 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "المبيعات");

  const safeName = (username || "user").replace(/[^a-zA-Z0-9_-]/g, "_");
  const today = new Date();
  const fname = `arzaq_${safeName}_${today.getFullYear()}-${(today.getMonth() + 1).toString().padStart(2, "0")}-${today.getDate().toString().padStart(2, "0")}.xlsx`;

  XLSX.writeFile(wb, fname);
}

export type ImportResult = {
  imported: Sale[];
  skipped: Array<{ row: number; reason: string }>;
};

const norm = (s: string) =>
  s.toLowerCase().trim().replace(/\s+/g, "").replace(/[()]/g, "");

const HEADER_MAP: Record<string, string> = {
  التاريخ: "date",
  date: "date",
  الوقت: "time",
  time: "time",
  المنتج: "product",
  product: "product",
  productname: "product",
  الصنف: "product",
  الشركة: "company",
  company: "company",
  brand: "company",
  الكمية: "qty",
  qty: "qty",
  quantity: "qty",
  count: "qty",
  العمولة: "commission",
  commission: "commission",
  "العمولةالإجمالية": "commission",
  "العمولةالإجماليةد.ل": "commission",
  "commission(د.ل)": "commission",
  amount: "commission",
};

function parseDateTime(dateVal: any, timeVal: any): Date | null {
  if (!dateVal && !timeVal) return null;

  // If date already a Date object (xlsx can do this with cellDates)
  if (dateVal instanceof Date) {
    if (timeVal && typeof timeVal === "string") {
      const m = timeVal.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?\s*(ص|م|am|pm)?/i);
      if (m) {
        let h = parseInt(m[1], 10);
        const mm = parseInt(m[2], 10);
        const ss = m[3] ? parseInt(m[3], 10) : 0;
        const ap = (m[4] || "").toLowerCase();
        if (ap === "م" || ap === "pm") {
          if (h < 12) h += 12;
        } else if (ap === "ص" || ap === "am") {
          if (h === 12) h = 0;
        }
        const d = new Date(dateVal);
        d.setHours(h, mm, ss, 0);
        return d;
      }
    }
    return new Date(dateVal);
  }

  if (typeof dateVal === "number") {
    // Excel serial date — XLSX gives this when cellDates is false.
    // Use SSF date utility approximation:
    const utcDays = Math.floor(dateVal - 25569);
    const utcMs = utcDays * 86400 * 1000;
    const d = new Date(utcMs);
    if (timeVal && typeof timeVal === "number") {
      const totalSec = Math.round(timeVal * 86400);
      d.setUTCHours(0, 0, 0, 0);
      d.setUTCSeconds(totalSec);
    }
    return d;
  }

  const str = String(dateVal).trim();
  // Accept yyyy-MM-dd, dd/MM/yyyy, dd-MM-yyyy
  let y = 0, mo = 0, da = 0;
  let m = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (m) {
    y = parseInt(m[1], 10);
    mo = parseInt(m[2], 10) - 1;
    da = parseInt(m[3], 10);
  } else {
    m = str.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (m) {
      da = parseInt(m[1], 10);
      mo = parseInt(m[2], 10) - 1;
      y = parseInt(m[3], 10);
    } else {
      const d = new Date(str);
      if (!isNaN(d.getTime())) return d;
      return null;
    }
  }
  let h = 0, mi = 0, se = 0;
  if (timeVal) {
    const tStr = String(timeVal).trim();
    const t = tStr.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?\s*(ص|م|am|pm)?/i);
    if (t) {
      h = parseInt(t[1], 10);
      mi = parseInt(t[2], 10);
      se = t[3] ? parseInt(t[3], 10) : 0;
      const ap = (t[4] || "").toLowerCase();
      if (ap === "م" || ap === "pm") {
        if (h < 12) h += 12;
      } else if (ap === "ص" || ap === "am") {
        if (h === 12) h = 0;
      }
    }
  }
  return new Date(y, mo, da, h, mi, se);
}

export async function importSalesFromExcel(file: File): Promise<ImportResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { cellDates: true });
  const wsName = wb.SheetNames[0];
  if (!wsName) {
    return { imported: [], skipped: [{ row: 0, reason: "ملف فارغ" }] };
  }
  const ws = wb.Sheets[wsName];
  const rows: Record<string, any>[] = XLSX.utils.sheet_to_json(ws, {
    defval: "",
    raw: false,
  });

  const imported: Sale[] = [];
  const skipped: ImportResult["skipped"] = [];

  rows.forEach((row, idx) => {
    const rowNum = idx + 2; // +1 for header, +1 for 1-based
    const mapped: Record<string, any> = {};
    Object.keys(row).forEach((k) => {
      const key = HEADER_MAP[norm(k)] ?? norm(k);
      mapped[key] = row[k];
    });

    const product = String(mapped.product || "").trim();
    const company = String(mapped.company || "").trim();
    const commRaw = mapped.commission;
    const qtyRaw = mapped.qty ?? 1;

    if (!product) {
      skipped.push({ row: rowNum, reason: "اسم المنتج مفقود" });
      return;
    }
    const commission = parseFloat(String(commRaw));
    if (isNaN(commission) || commission < 0) {
      skipped.push({ row: rowNum, reason: "قيمة العمولة غير صحيحة" });
      return;
    }
    const quantity = Math.max(1, parseInt(String(qtyRaw), 10) || 1);

    const dt = parseDateTime(mapped.date, mapped.time) ?? new Date();

    imported.push({
      id: crypto.randomUUID(),
      productName: product,
      company,
      commission,
      quantity,
      date: dt.toISOString(),
    });
  });

  return { imported, skipped };
}
