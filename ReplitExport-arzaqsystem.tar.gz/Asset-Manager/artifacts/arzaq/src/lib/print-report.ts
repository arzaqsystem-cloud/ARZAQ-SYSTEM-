import type { Sale } from "./store";

type ReportInput = {
  sales: Sale[];
  baseSalary: number;
  username: string | null;
  generatedAt: Date;
  filterLabel?: string;
};

const escape = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const pad = (n: number) => n.toString().padStart(2, "0");

const formatDateTime = (iso: string) => {
  const d = new Date(iso);
  const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const h24 = d.getHours();
  const period = h24 >= 12 ? "م" : "ص";
  let h12 = h24 % 12;
  if (h12 === 0) h12 = 12;
  const time = `${pad(h12)}:${pad(d.getMinutes())}:${pad(d.getSeconds())} ${period}`;
  return { date, time };
};

const ARABIC_MONTHS = [
  "يناير",
  "فبراير",
  "مارس",
  "أبريل",
  "مايو",
  "يونيو",
  "يوليو",
  "أغسطس",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];

const formatGeneratedAt = (d: Date) =>
  `${d.getDate()} ${ARABIC_MONTHS[d.getMonth()]} ${d.getFullYear()} — ${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;

export function openPrintReport({
  sales,
  baseSalary,
  username,
  generatedAt,
  filterLabel,
}: ReportInput): void {
  const totalCommission = sales.reduce((acc, s) => acc + s.commission, 0);
  const totalProjected = totalCommission + baseSalary;
  const operationsCount = sales.length;

  const totalQty = sales.reduce((acc, s) => acc + (s.quantity ?? 1), 0);

  const rows = sales
    .slice()
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .map((s, i) => {
      const { date, time } = formatDateTime(s.date);
      const qty = s.quantity ?? 1;
      return `
        <tr>
          <td class="num col-idx"><span class="idx-pill">${i + 1}</span></td>
          <td class="col-product">${escape(s.productName)}</td>
          <td class="col-company"><span class="company">${escape(s.company || "-")}</span></td>
          <td class="num col-qty"><span class="qty">${qty}</span></td>
          <td class="num col-money"><span class="money-badge">${s.commission.toFixed(2)}<span class="cur">د.ل</span></span></td>
          <td class="num col-date"><div class="dt"><span>${date}</span><span class="time">${time}</span></div></td>
        </tr>
      `;
    })
    .join("");

  const tableBody = sales.length
    ? rows
    : `<tr><td colspan="6" class="empty">لا توجد مبيعات في هذا التقرير</td></tr>`;

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>تقرير ARZAQ — ${escape(username || "مستخدم")}</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet" />
<style>
  * { box-sizing: border-box; }
  html, body {
    margin: 0;
    padding: 0;
    font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
    color: #1a1a1a;
    background: #f3f4f6;
  }
  .page {
    max-width: 820px;
    margin: 24px auto;
    background: #fff;
    padding: 32px 36px 40px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    border-radius: 8px;
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 3px solid #0d3b2e;
    padding-bottom: 16px;
    margin-bottom: 18px;
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 14px;
  }
  .logo {
    width: 60px;
    height: 60px;
    background: #0d3b2e;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .logo svg { display: block; }
  .brand-text h1 {
    margin: 0;
    font-size: 24px;
    font-weight: 900;
    letter-spacing: 0.15em;
    color: #0d3b2e;
  }
  .brand-text p {
    margin: 2px 0 0;
    font-size: 11px;
    letter-spacing: 0.4em;
    color: #d4a64a;
    font-weight: 700;
  }
  .meta {
    text-align: left;
    font-size: 12px;
    color: #4b5563;
    line-height: 1.7;
  }
  .meta b { color: #0d3b2e; font-weight: 700; }

  .title-bar {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    margin: 0 0 14px;
  }
  .title-bar h2 {
    font-size: 18px;
    font-weight: 800;
    color: #0d3b2e;
    margin: 0;
  }
  .title-bar .filter {
    font-size: 12px;
    color: #6b7280;
    background: #f3f4f6;
    padding: 4px 10px;
    border-radius: 999px;
    font-weight: 600;
  }

  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 13px;
    margin-bottom: 18px;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    overflow: hidden;
  }
  thead th {
    background: linear-gradient(180deg, #0f4636 0%, #0d3b2e 100%);
    color: #fff;
    font-weight: 700;
    padding: 11px 8px;
    text-align: right;
    font-size: 12px;
    letter-spacing: 0.02em;
    border-bottom: 2px solid #d4a64a;
  }
  /* Soft column tinting (calm pastel palette) */
  thead th.col-idx     { background-image: linear-gradient(180deg, #5a4b6f, #4a3d5c); width: 42px; }
  thead th.col-product { background-image: linear-gradient(180deg, #4a5a3d, #3d4a31); }
  thead th.col-company { background-image: linear-gradient(180deg, #3a5f55, #2d4a43); }
  thead th.col-qty     { background-image: linear-gradient(180deg, #8a6b3a, #6f5530); }
  thead th.col-money   { background-image: linear-gradient(180deg, #2f6e5a, #235848); }
  thead th.col-date    { background-image: linear-gradient(180deg, #475569, #364154); }

  tbody td {
    padding: 9px 8px;
    border-bottom: 1px solid #eef2f0;
    vertical-align: middle;
  }
  tbody tr:last-child td { border-bottom: none; }

  /* Calm pastel column backgrounds — easy on the eye */
  tbody td.col-idx     { background: #faf7fc; color: #6b5b87; font-weight: 700; }
  tbody td.col-product { background: #fbfdf6; color: #1f2937; font-weight: 700; }
  tbody td.col-company { background: #f5fbf8; }
  tbody td.col-qty     { background: #fdf9ef; }
  tbody td.col-money   { background: #f0fbf6; }
  tbody td.col-date    { background: #f7f9fc; }

  /* Subtle alternate row banding (preserves column tint hierarchy) */
  tbody tr:nth-child(even) td.col-idx     { background: #f5f0fa; }
  tbody tr:nth-child(even) td.col-product { background: #f6faec; }
  tbody tr:nth-child(even) td.col-company { background: #ecf7f1; }
  tbody tr:nth-child(even) td.col-qty     { background: #fbf3df; }
  tbody tr:nth-child(even) td.col-money   { background: #e6f7ee; }
  tbody tr:nth-child(even) td.col-date    { background: #eef2f8; }

  td.num { font-variant-numeric: tabular-nums; }

  .money-badge {
    display: inline-flex;
    align-items: baseline;
    gap: 3px;
    padding: 4px 10px;
    background: #ffffff;
    border: 1px solid #bbe5d0;
    border-radius: 8px;
    font-weight: 800;
    color: #047857;
    white-space: nowrap;
    box-shadow: 0 1px 0 rgba(4, 120, 87, 0.05);
  }
  .money-badge .cur { font-size: 10px; color: #047857; opacity: 0.7; font-weight: 600; }

  .company {
    display: inline-block;
    padding: 3px 9px;
    background: #ffffff;
    color: #065f46;
    border: 1px solid #bbe5d0;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.05em;
    box-shadow: 0 1px 0 rgba(6, 95, 70, 0.04);
  }
  .qty {
    display: inline-block;
    min-width: 32px;
    padding: 3px 10px;
    background: #ffffff;
    color: #92400e;
    border: 1px solid #f5d28a;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 800;
    text-align: center;
    box-shadow: 0 1px 0 rgba(146, 64, 14, 0.04);
  }
  .idx-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: #ffffff;
    color: #6b5b87;
    border: 1px solid #d8c8e6;
    font-weight: 800;
    font-size: 11px;
    box-shadow: 0 1px 0 rgba(91, 75, 113, 0.04);
  }
  .dt { display: flex; flex-direction: column; line-height: 1.3; }
  .dt .time {
    color: #475569;
    font-size: 11px;
    font-weight: 700;
    margin-top: 2px;
  }
  td.empty {
    text-align: center;
    padding: 30px;
    color: #9ca3af;
    font-style: italic;
    background: #fbfcfe !important;
  }

  .summary {
    border: 1px solid #d6e5dc;
    border-radius: 14px;
    padding: 16px 18px;
    margin-bottom: 22px;
    background: linear-gradient(135deg, #f3faf6 0%, #ffffff 70%);
  }
  .summary h3 {
    margin: 0 0 12px;
    font-size: 15px;
    color: #0d3b2e;
    font-weight: 800;
    border-bottom: 1px dashed #c7dad0;
    padding-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .summary-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
  }
  .sum-cell {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 10px 12px;
    border-top: 3px solid var(--accent, #94a3b8);
    box-shadow: 0 1px 0 rgba(0,0,0,0.02);
  }
  .sum-cell.tone-ops      { --accent: #6b5b87; background: #faf7fc; }
  .sum-cell.tone-qty      { --accent: #8a6b3a; background: #fdf9ef; }
  .sum-cell.tone-comm     { --accent: #2f6e5a; background: #f0fbf6; }
  .sum-cell.tone-base     { --accent: #475569; background: #f7f9fc; }

  .sum-cell .label {
    font-size: 10.5px;
    color: #6b7280;
    font-weight: 700;
    margin-bottom: 4px;
  }
  .sum-cell .value {
    font-size: 18px;
    font-weight: 900;
    color: #1a1a1a;
    font-variant-numeric: tabular-nums;
  }
  .sum-cell .value .cur {
    font-size: 11px;
    color: #6b7280;
    font-weight: 600;
    margin-inline-start: 2px;
  }
  .sum-cell.highlight {
    background: linear-gradient(135deg, #0d3b2e 0%, #155544 100%);
    border-color: #0d3b2e;
    border-top-color: #d4a64a;
    border-top-width: 4px;
    box-shadow: 0 4px 12px rgba(13, 59, 46, 0.15);
  }
  .sum-cell.highlight .label { color: #d4a64a; font-size: 12px; }
  .sum-cell.highlight .value { color: #fff; font-size: 22px; }
  .sum-cell.highlight .value .cur { color: #d4a64a; opacity: 0.85; }

  .disclaimer {
    border: 2px solid #b91c1c;
    background: #fef2f2;
    border-radius: 12px;
    padding: 16px 18px;
    margin-top: 6px;
  }
  .disclaimer h3 {
    margin: 0 0 10px;
    color: #991b1b;
    font-size: 16px;
    font-weight: 900;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .disclaimer p {
    margin: 6px 0;
    color: #7f1d1d;
    font-size: 13px;
    line-height: 1.85;
    font-weight: 600;
  }
  .disclaimer p.intro { font-weight: 800; }

  .footer {
    margin-top: 22px;
    text-align: center;
    color: #9ca3af;
    font-size: 11px;
    letter-spacing: 0.2em;
    font-weight: 700;
  }

  .actions {
    text-align: center;
    margin: 0 0 16px;
  }
  .actions button {
    background: #0d3b2e;
    color: #fff;
    border: none;
    padding: 12px 24px;
    border-radius: 999px;
    font-family: inherit;
    font-size: 14px;
    font-weight: 800;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(13, 59, 46, 0.25);
  }
  .actions button:hover { background: #155544; }

  @media print {
    body { background: #fff; }
    .page { box-shadow: none; margin: 0; max-width: none; border-radius: 0; padding: 16mm 14mm; }
    .actions { display: none; }
    thead { display: table-header-group; }
    tr { page-break-inside: avoid; }
    .summary, .disclaimer { page-break-inside: avoid; }
  }
</style>
</head>
<body>
  <div class="actions">
    <button onclick="window.print()">طباعة التقرير</button>
  </div>
  <div class="page">
    <div class="header">
      <div class="brand">
        <div class="logo">
          <svg width="40" height="40" viewBox="0 0 64 64" fill="none">
            <path d="M14 46 L26 18 L38 46" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
            <path d="M19 36 L33 36" stroke="#fff" stroke-width="5" stroke-linecap="round"/>
            <circle cx="46" cy="20" r="5" fill="#d4a64a"/>
            <path d="M44 46 L52 30" stroke="#d4a64a" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <div class="brand-text">
          <h1>ARZAQ</h1>
          <p>PRO · ULTRA</p>
        </div>
      </div>
      <div class="meta">
        <div><b>الموظف:</b> ${escape(username || "غير محدد")}</div>
        <div><b>تاريخ التقرير:</b> ${escape(formatGeneratedAt(generatedAt))}</div>
      </div>
    </div>

    <div class="title-bar">
      <h2>تقرير المبيعات والعمولات</h2>
      ${filterLabel ? `<span class="filter">${escape(filterLabel)}</span>` : ""}
    </div>

    <div class="summary">
      <h3>📊 ملخص العمولات والراتب</h3>
      <div class="summary-grid">
        <div class="sum-cell tone-ops">
          <div class="label">عدد العمليات</div>
          <div class="value">${operationsCount}</div>
        </div>
        <div class="sum-cell tone-qty">
          <div class="label">إجمالي القطع المباعة</div>
          <div class="value">${totalQty}</div>
        </div>
        <div class="sum-cell tone-comm">
          <div class="label">إجمالي العمولات</div>
          <div class="value">${totalCommission.toFixed(2)}<span class="cur">د.ل</span></div>
        </div>
        <div class="sum-cell tone-base">
          <div class="label">الراتب الأساسي</div>
          <div class="value">${baseSalary.toFixed(2)}<span class="cur">د.ل</span></div>
        </div>
        <div class="sum-cell highlight" style="grid-column: span 4;">
          <div class="label">الراتب الإجمالي المتوقع</div>
          <div class="value">${totalProjected.toFixed(2)}<span class="cur">د.ل</span></div>
        </div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th class="col-idx">#</th>
          <th class="col-product">المنتج</th>
          <th class="col-company" style="width:120px;">الشركة</th>
          <th class="col-qty" style="width:70px;">الكمية</th>
          <th class="col-money" style="width:130px;">العمولة</th>
          <th class="col-date" style="width:160px;">التاريخ والتوقيت</th>
        </tr>
      </thead>
      <tbody>
        ${tableBody}
      </tbody>
    </table>

    <div class="disclaimer">
      <h3>إخلاء المسؤولية القانونية (تنبيه هام) ⚖️</h3>
      <p class="intro">نود أن نكون صريحين معك من البداية:</p>
      <p>ARZAQ أداة مساعدة لتنظيم العمل وتسهيل الحسابات اليومية.</p>
      <p>كافة البيانات المدخلة، وحسابات العمولات، والرواتب الناتجة عن المنظومة هي مجرد تقديرات وحسابات تقريبية.</p>
      <p>لا يعتد بهذه النتائج كوثائق رسمية أو قانونية في أي نزاعات أو معاملات مالية ملزمة. نحن غير مسؤولين عن أي فروقات أو أخطاء قد تترتب على استخدام هذه التقديرات في غير الغرض المخصص لها.</p>
    </div>

    <div class="footer">ARZAQ PRO ULTRA — تقرير مولد آلياً</div>
  </div>
  <script>
    setTimeout(function(){
      try { window.focus(); } catch(e) {}
    }, 50);
  </script>
</body>
</html>`;

  const w = window.open("", "_blank", "width=900,height=900");
  if (!w) {
    alert("الرجاء السماح بالنوافذ المنبثقة لطباعة التقرير");
    return;
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
}
