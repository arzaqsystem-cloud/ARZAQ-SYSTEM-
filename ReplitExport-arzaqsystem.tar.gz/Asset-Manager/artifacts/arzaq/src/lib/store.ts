import { useEffect, useMemo, useState } from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";

export type UserRole = "admin" | "user";

export type User = {
  user: string;
  pass: string;
  status: "active" | "frozen";
  role?: UserRole;
};

export const ADMIN_SEED: User = {
  user: "mohamed kukan",
  pass: "kukan1992",
  status: "active",
  role: "admin",
};

export const SUPPORT_EMAIL = "arzaqsystem@gmail.com";

export type Product = {
  id: string;
  name: string;
  company: string;
  comm: number;
  type: "fixed" | "percent";
};

export type Sale = {
  id: string;
  productName: string;
  company: string;
  commission: number; // total commission (already × quantity)
  quantity?: number; // defaults to 1 for legacy rows
  date: string;
};

export const COMPANIES = [
  "TECNO",
  "HONOR",
  "TECLAST",
  "SAMSUNG",
  "APPLE",
  "ACCESSORIES",
] as const;

export const DEFAULT_PRODUCTS: Product[] = [
  { id: "tecno-spark-go-2", name: "SPARK GO 2", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-spark-go-3", name: "SPARK GO 3", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-spark-40c", name: "SPARK 40C", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-spark-40", name: "SPARK 40", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-spark-40-pro", name: "SPARK 40 PRO", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-spark-slim", name: "SPARK SLIM", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-pova-7", name: "POVA 7", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-pova-7-ultra", name: "POVA 7 ULTRA", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-pova-slim", name: "POVA SLIM", company: "TECNO", comm: 15, type: "fixed" },
  { id: "tecno-camon-40-ser", name: "CAMON 40 SER", company: "TECNO", comm: 10, type: "fixed" },
  { id: "tecno-camon-50-ser", name: "CAMON 50 SER", company: "TECNO", comm: 25, type: "fixed" },

  { id: "honor-play-10", name: "PLAY 10", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x5b-plus-128", name: "X5B PLUS 128+", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x5c-64-4", name: "X5C 64+4", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x5c-plus-128", name: "X5C PLUS 128+", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x6c-128-6", name: "X6C 128+6", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x6c-256-6", name: "X6C 256+6", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x7d-4g-5g", name: "X7D 4G+5G", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x8c", name: "X8C", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x9c", name: "X9C", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-x9d", name: "X9D", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-400-lite", name: "400 LITE", company: "HONOR", comm: 10, type: "fixed" },
  { id: "honor-400", name: "400", company: "HONOR", comm: 20, type: "fixed" },
  { id: "honor-magic-7-pro", name: "MAGIC 7 PRO", company: "HONOR", comm: 50, type: "fixed" },
  { id: "honor-magic-8-pro", name: "MAGIC 8 PRO", company: "HONOR", comm: 100, type: "fixed" },
  { id: "honor-magiv-v5", name: "MAGIV V5", company: "HONOR", comm: 100, type: "fixed" },
  { id: "honor-pad-x7a", name: "PAD X7A", company: "HONOR", comm: 15, type: "fixed" },
  { id: "honor-pad-x8a", name: "PAD X8A", company: "HONOR", comm: 15, type: "fixed" },
  { id: "honor-pad-x9a", name: "PAD X9A", company: "HONOR", comm: 15, type: "fixed" },
  { id: "honor-pad-10", name: "PAD 10", company: "HONOR", comm: 15, type: "fixed" },
  { id: "honor-magic-pad-3", name: "MAGIC PAD 3", company: "HONOR", comm: 25, type: "fixed" },

  { id: "teclast-teclast", name: "TECLAST", company: "TECLAST", comm: 15, type: "fixed" },

  { id: "samsung-samsung", name: "SAMSUNG", company: "SAMSUNG", comm: 2, type: "fixed" },

  { id: "apple-iphone", name: "IPHONE", company: "APPLE", comm: 25, type: "fixed" },
  { id: "apple-ipad", name: "IPAD", company: "APPLE", comm: 25, type: "fixed" },
  { id: "apple-airpods", name: "AIRPODS", company: "APPLE", comm: 10, type: "fixed" },
  { id: "apple-watch", name: "WATCH", company: "APPLE", comm: 20, type: "fixed" },

  { id: "acc-case", name: "CASE", company: "ACCESSORIES", comm: 10, type: "percent" },
  { id: "acc-glass", name: "GLASS", company: "ACCESSORIES", comm: 10, type: "percent" },
  { id: "acc-oraimo", name: "ORAIMO", company: "ACCESSORIES", comm: 10, type: "percent" },
  { id: "acc-honor", name: "HONOR", company: "ACCESSORIES", comm: 5, type: "percent" },
  { id: "acc-hifuture", name: "HIFUTURE", company: "ACCESSORIES", comm: 5, type: "percent" },
  { id: "acc-anker", name: "ANKER", company: "ACCESSORIES", comm: 5, type: "percent" },
  { id: "acc-jbl", name: "JBL", company: "ACCESSORIES", comm: 2, type: "percent" },
  { id: "acc-samsung", name: "SAMSUNG", company: "ACCESSORIES", comm: 2, type: "percent" },
  { id: "acc-apple", name: "APPLE", company: "ACCESSORIES", comm: 2, type: "percent" },
  { id: "acc-green", name: "GREEN", company: "ACCESSORIES", comm: 10, type: "percent" },
];

export function useTerms() {
  return useLocalStorage<"yes" | "no">("arzaq:terms", "no");
}

export function useUsers() {
  return useLocalStorage<User[]>("arzaq:users", [ADMIN_SEED]);
}

export function useCurrentUser() {
  return useLocalStorage<string | null>("arzaq:currentUser", null);
}

/**
 * Ensures the seeded admin always exists in the user list, with admin role
 * and active status. Safe to call from app root on every mount.
 */
export function useEnsureAdmin() {
  const [users, setUsers] = useUsers();

  useEffect(() => {
    const existing = users.find((u) => u.user === ADMIN_SEED.user);
    const needsSeed =
      !existing ||
      existing.role !== "admin" ||
      existing.pass !== ADMIN_SEED.pass ||
      existing.status !== "active";

    if (needsSeed) {
      const others = users.filter((u) => u.user !== ADMIN_SEED.user);
      setUsers([ADMIN_SEED, ...others]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [users.length]);
}

export function isAdmin(username: string | null, users: User[]): boolean {
  if (!username) return false;
  const u = users.find((x) => x.user === username);
  return u?.role === "admin";
}

export function useProducts() {
  return useLocalStorage<Product[]>("arzaq:products:v2", DEFAULT_PRODUCTS);
}

/* ===========================================================
 * Per-user sales + base salary storage
 * Keys: arzaq:sales:<username> · arzaq:baseSalary:<username>
 * Legacy keys (arzaq:sales, arzaq:baseSalary) auto-migrate on
 * first login of any user after upgrade.
 * =========================================================== */

export const salesKey = (username: string) => `arzaq:sales:${username}`;
export const baseSalaryKey = (username: string) =>
  `arzaq:baseSalary:${username}`;

export function readSalesFor(username: string): Sale[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(salesKey(username));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function readBaseSalaryFor(username: string): number {
  if (typeof window === "undefined") return 250;
  try {
    const raw = window.localStorage.getItem(baseSalaryKey(username));
    return raw ? JSON.parse(raw) : 250;
  } catch {
    return 250;
  }
}

/** Migrates the old global sales/baseSalary keys to the current user. */
export function useMigrateLegacyData() {
  const [currentUser] = useCurrentUser();
  useEffect(() => {
    if (!currentUser || typeof window === "undefined") return;

    const legacySalesKey = "arzaq:sales";
    const legacySalary = "arzaq:baseSalary";

    const legacySales = window.localStorage.getItem(legacySalesKey);
    if (legacySales) {
      const userKey = salesKey(currentUser);
      if (!window.localStorage.getItem(userKey)) {
        window.localStorage.setItem(userKey, legacySales);
        window.dispatchEvent(new Event("local-storage"));
      }
      window.localStorage.removeItem(legacySalesKey);
    }

    const legacyBase = window.localStorage.getItem(legacySalary);
    if (legacyBase) {
      const userKey = baseSalaryKey(currentUser);
      if (!window.localStorage.getItem(userKey)) {
        window.localStorage.setItem(userKey, legacyBase);
        window.dispatchEvent(new Event("local-storage"));
      }
      window.localStorage.removeItem(legacySalary);
    }
  }, [currentUser]);
}

const EMPTY_SALES_KEY = "arzaq:sales:__none__";
const EMPTY_BASE_KEY = "arzaq:baseSalary:__none__";

export function useSales() {
  const [currentUser] = useCurrentUser();
  const key = currentUser ? salesKey(currentUser) : EMPTY_SALES_KEY;
  return useLocalStorage<Sale[]>(key, []);
}

export function useBaseSalary() {
  const [currentUser] = useCurrentUser();
  const key = currentUser ? baseSalaryKey(currentUser) : EMPTY_BASE_KEY;
  return useLocalStorage<number>(key, 250);
}

/**
 * Reactive snapshot of every user's sales — used by the admin dashboard.
 * Re-reads when localStorage changes (across this tab and other tabs).
 */
export function useAllUserSales(usernames: string[]): Record<string, Sale[]> {
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const handler = () => setVersion((v) => v + 1);
    window.addEventListener("storage", handler);
    window.addEventListener("local-storage", handler);
    return () => {
      window.removeEventListener("storage", handler);
      window.removeEventListener("local-storage", handler);
    };
  }, []);

  return useMemo(() => {
    const map: Record<string, Sale[]> = {};
    usernames.forEach((u) => {
      map[u] = readSalesFor(u);
    });
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usernames.join("|"), version]);
}

export function useAllUserBaseSalaries(
  usernames: string[],
): Record<string, number> {
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const handler = () => setVersion((v) => v + 1);
    window.addEventListener("storage", handler);
    window.addEventListener("local-storage", handler);
    return () => {
      window.removeEventListener("storage", handler);
      window.removeEventListener("local-storage", handler);
    };
  }, []);

  return useMemo(() => {
    const map: Record<string, number> = {};
    usernames.forEach((u) => {
      map[u] = readBaseSalaryFor(u);
    });
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usernames.join("|"), version]);
}
