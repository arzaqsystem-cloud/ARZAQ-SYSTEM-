import { useEffect, useState } from "react";

/**
 * A clock that ticks only while the document is visible. When the user
 * leaves the tab / minimizes the window the interval is cleared so the
 * page does no background work. When they return, the clock immediately
 * jumps to the current time (auto-refresh on resume).
 */
export function useVisibilityClock(intervalMs: number = 1000): Date {
  const [now, setNow] = useState<Date>(() => new Date());

  useEffect(() => {
    let id: number | null = null;

    const start = () => {
      if (id !== null) return;
      setNow(new Date());
      id = window.setInterval(() => setNow(new Date()), intervalMs);
    };

    const stop = () => {
      if (id !== null) {
        window.clearInterval(id);
        id = null;
      }
    };

    const onVisibility = () => {
      if (document.visibilityState === "visible") start();
      else stop();
    };

    if (document.visibilityState === "visible") start();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("focus", onVisibility);

    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("focus", onVisibility);
    };
  }, [intervalMs]);

  return now;
}

/**
 * Format a date in 12-hour clock with Arabic AM/PM.
 * Example: 03:14:25 م
 */
export function formatTime12(d: Date, withSeconds = true): string {
  const h24 = d.getHours();
  const m = d.getMinutes();
  const s = d.getSeconds();
  const period = h24 >= 12 ? "م" : "ص";
  let h12 = h24 % 12;
  if (h12 === 0) h12 = 12;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return withSeconds
    ? `${pad(h12)}:${pad(m)}:${pad(s)} ${period}`
    : `${pad(h12)}:${pad(m)} ${period}`;
}
