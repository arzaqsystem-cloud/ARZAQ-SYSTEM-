import { useState, useEffect, memo } from "react";
import { useLocation } from "wouter";
import {
  useTerms,
  useCurrentUser,
  useEnsureAdmin,
  useUsers,
  isAdmin,
  useMigrateLegacyData,
} from "@/lib/store";
import { motion, AnimatePresence } from "framer-motion";
import {
  Calculator,
  History,
  Package,
  Settings,
  Crown,
  BarChart3,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import SalesTab from "@/components/tabs/sales";
import HistoryTab from "@/components/tabs/history";
import ProductsTab from "@/components/tabs/products";
import SettingsTab from "@/components/tabs/settings";
import AdminTab from "@/components/tabs/admin";
import { ArzaqMark } from "@/components/arzaq-logo";
import { useVisibilityClock, formatTime12 } from "@/lib/visibility-clock";

type TabId = "sales" | "history" | "products" | "admin" | "settings";

const HeaderClock = memo(function HeaderClock() {
  const now = useVisibilityClock(1000);
  return (
    <div className="px-4 pb-2.5 flex items-center justify-between text-[11px] font-bold text-primary-foreground/85">
      <span>{format(now, "EEEE، d MMMM yyyy", { locale: ar })}</span>
      <span className="tabular-nums tracking-wider bg-white/10 px-2 py-0.5 rounded-md min-w-[96px] text-center">
        {formatTime12(now)}
      </span>
    </div>
  );
});

export default function MainApp() {
  const [, setLocation] = useLocation();
  const [terms] = useTerms();
  const [currentUser] = useCurrentUser();
  const [users] = useUsers();

  useEnsureAdmin();
  useMigrateLegacyData();

  const admin = isAdmin(currentUser, users);

  const [activeTab, setActiveTab] = useState<TabId>("sales");

  // Auth guard
  useEffect(() => {
    if (terms !== "yes") {
      setLocation("/");
      return;
    }
    if (!currentUser) {
      setLocation("/login");
      return;
    }
  }, [terms, currentUser, setLocation]);

  // If user is no longer admin (e.g. demoted), bounce away from admin tab.
  useEffect(() => {
    if (activeTab === "admin" && !admin) setActiveTab("sales");
  }, [admin, activeTab]);

  if (!currentUser) return null;

  const baseTabs = [
    { id: "sales" as const, label: "المبيعات", icon: Calculator, component: SalesTab },
    { id: "history" as const, label: "السجل", icon: History, component: HistoryTab },
    { id: "products" as const, label: "الأصناف", icon: Package, component: ProductsTab },
  ];

  const adminTab = {
    id: "admin" as const,
    label: "المسؤول",
    icon: BarChart3,
    component: AdminTab,
  };

  const settingsTab = {
    id: "settings" as const,
    label: "الإعدادات",
    icon: Settings,
    component: SettingsTab,
  };

  const tabs = admin
    ? [...baseTabs, adminTab, settingsTab]
    : [...baseTabs, settingsTab];

  return (
    <div className="min-h-[100dvh] w-full bg-muted/20 flex flex-col md:items-center">
      <div className="w-full md:max-w-md h-[100dvh] flex flex-col relative bg-background md:border-x md:shadow-2xl overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 bg-primary text-primary-foreground z-10 shadow-md">
          <div className="h-16 flex items-center px-3 justify-between">
            <div className="flex items-center gap-2.5">
              <ArzaqMark size={36} />
              <div className="leading-none">
                <h1 className="font-black tracking-[0.18em] text-base">
                  ARZAQ
                </h1>
                <p className="text-[9px] text-primary-foreground/70 uppercase tracking-[0.3em] mt-1">
                  PRO ULTRA
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-primary-foreground/10 px-3 py-1 rounded-full border border-white/10">
              {admin ? (
                <Crown size={12} className="text-secondary" />
              ) : (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              )}
              <span className="text-xs font-bold truncate max-w-[140px]">
                {currentUser}
              </span>
            </div>
          </div>

          <HeaderClock />
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden relative pb-20">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
              className="min-h-full"
            >
              {tabs.map(
                (tab) =>
                  tab.id === activeTab && <tab.component key={tab.id} />,
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Bottom Navigation */}
        <nav className="absolute bottom-0 left-0 right-0 h-20 bg-card border-t border-card-border shadow-[0_-10px_40px_-10px_rgba(0,0,0,0.1)] z-20 px-1.5 pb-safe pt-2">
          <div className="flex items-center justify-around h-full max-w-md mx-auto">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="relative flex flex-col items-center justify-center flex-1 min-w-0 h-full gap-1 outline-none tap-highlight-transparent"
                >
                  <motion.div
                    animate={{
                      y: isActive ? -4 : 0,
                      scale: isActive ? 1.1 : 1,
                    }}
                    className={`flex items-center justify-center w-10 h-10 rounded-2xl transition-colors duration-300 ${
                      isActive
                        ? "bg-primary text-primary-foreground shadow-md"
                        : "text-muted-foreground"
                    }`}
                  >
                    <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                  </motion.div>
                  <span
                    className={`text-[9.5px] font-bold transition-colors truncate max-w-full px-0.5 ${
                      isActive ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {tab.label}
                  </span>

                  {isActive && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="absolute -bottom-2 w-1.5 h-1.5 rounded-full bg-primary"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
