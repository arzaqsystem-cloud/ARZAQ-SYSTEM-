import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useTerms } from "@/lib/store";
import { CheckCircle2 } from "lucide-react";
import { ArzaqMark } from "@/components/arzaq-logo";

type Section = {
  title: string;
  emoji: string;
  body: string[];
  tone?: "default" | "danger";
};

const SECTIONS: Section[] = [
  {
    title: "خصوصية بياناتك (أمانك أولاً)",
    emoji: "🔒",
    body: [
      "هذا هو الركن الأهم لدينا: بياناتك ملك لك وحدك.",
      "جميع البيانات التي تدخلها في المنظومة تُحفظ محلياً على هاتفك فقط.",
      "نحن مطورو المنظومة لا يمكننا الوصول إلى بياناتك، أو رؤيتها، أو سحبها بأي شكل من الأشكال.",
      "حماية هاتفك ونسخ بياناتك احتياطياً هي مسؤوليتك الشخصية، لأننا لا نملك أي نسخة منها.",
    ],
  },
  {
    title: "إخلاء المسؤولية القانونية (تنبيه هام)",
    emoji: "⚖️",
    body: [
      "ARZAQ أداة مساعدة لتنظيم العمل وتسهيل الحسابات اليومية.",
      "كافة البيانات المدخلة، وحسابات العمولات، والرواتب الناتجة عن المنظومة هي مجرد تقديرات وحسابات تقريبية.",
      "لا يعتد بهذه النتائج كوثائق رسمية أو قانونية في أي نزاعات أو معاملات مالية ملزمة. نحن غير مسؤولين عن أي فروقات أو أخطاء قد تترتب على استخدام هذه التقديرات في غير الغرض المخصص لها.",
    ],
  },
  {
    title: "نظام الاشتراك المستقبلي",
    emoji: "💎",
    body: [
      "حالياً، المنظومة متاحة للاستخدام كما هي، ولكن:",
      "قد تتطور ARZAQ مستقبلاً لتشمل ميزات متقدمة أو خدمات إضافية قد تتطلب اشتراكاً (شهرياً أو سنوياً).",
      "في حال تفعيل نظام الاشتراكات، سنقوم بإعلامك مسبقاً وبكل وضوح قبل تطبيق أي رسوم.",
    ],
  },
  {
    title: "حقوق الملكية",
    emoji: "©️",
    body: [
      "الاسم ARZAQ، البرمجيات، والتصميم هي ثمرة مجهودنا. يسعدنا استخدامك لها، ولكن نرجو عدم محاولة نسخ الكود أو إعادة بيعه دون إذن منا.",
    ],
  },
  {
    title: "التعديلات والتحديثات",
    emoji: "🔄",
    body: [
      "نحن نعمل دائماً على تطوير ARZAQ. قد نقوم بتحديث هذه الشروط من وقت لآخر، وسنحرص دائماً أن تظل البساطة هي عنواننا.",
    ],
  },
  {
    title: "نحن هنا للمساعدة",
    emoji: "💬",
    body: [
      "إذا واجهتك أي مشكلة تقنية أو كان لديك اقتراح لتطوير المنظومة، فريق ARZAQ يرحب دائماً برسائلك.",
    ],
  },
  {
    title: "تذكير مهم",
    emoji: "⚠️",
    body: [
      "بما أن البيانات تُحفظ على الهاتف فقط، تذكر دائماً أن مسح التطبيق أو تهيئة الهاتف (Format) قد يؤدي لفقدان بياناتك ما لم تكن قد أخذت نسخة احتياطية يدوياً.",
    ],
    tone: "danger",
  },
];

export default function Terms() {
  const [, setLocation] = useLocation();
  const [, setTerms] = useTerms();

  const handleAccept = () => {
    setTerms("yes");
    setLocation("/login");
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.07 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -16 },
    show: { opacity: 1, x: 0 },
  };

  return (
    <div className="min-h-[100dvh] w-full bg-muted/20 flex flex-col items-center">
      <div className="w-full max-w-md flex-1 flex flex-col px-5 pb-6">
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-10 pb-6 flex flex-col items-center text-center"
        >
          <div className="mb-5">
            <ArzaqMark size={72} variant="dark" className="drop-shadow-lg" />
          </div>
          <h1 className="text-2xl font-black text-foreground">
            شروط استخدام منظومة ARZAQ
          </h1>
          <p className="text-muted-foreground mt-2 text-sm leading-relaxed max-w-[320px]">
            أهلاً بك في ARZAQ! نحن هنا لنسهل عليك إدارة أعمالك بكل خصوصية
            وأمان. هذه القواعد البسيطة تنظم علاقتنا معك.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="space-y-3 flex-1"
        >
          {SECTIONS.map((section, i) => (
            <motion.div
              key={section.title}
              variants={itemVariants}
              className={`p-4 rounded-2xl border shadow-sm ${
                section.tone === "danger"
                  ? "bg-destructive/5 border-destructive/30"
                  : "bg-card border-card-border"
              }`}
            >
              <div className="flex items-start gap-3 mb-2">
                <div className="text-2xl leading-none mt-0.5">
                  {section.emoji}
                </div>
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span
                      className={`text-xs font-bold ${
                        section.tone === "danger"
                          ? "text-destructive"
                          : "text-primary"
                      }`}
                    >
                      {i + 1}.
                    </span>
                    <h3
                      className={`font-bold text-base leading-tight ${
                        section.tone === "danger" ? "text-destructive" : ""
                      }`}
                    >
                      {section.title}
                    </h3>
                  </div>
                </div>
              </div>
              <ul className="space-y-1.5 ps-9">
                {section.body.map((line, j) => (
                  <li
                    key={j}
                    className={`text-sm leading-relaxed ${
                      section.tone === "danger"
                        ? "text-destructive/90"
                        : "text-muted-foreground"
                    }`}
                  >
                    {line}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="pt-6 sticky bottom-0"
        >
          <Button
            size="lg"
            className="w-full h-14 text-lg font-bold rounded-2xl shadow-md gap-2"
            onClick={handleAccept}
          >
            <CheckCircle2 size={22} />
            موافق وأرغب بالمتابعة
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
