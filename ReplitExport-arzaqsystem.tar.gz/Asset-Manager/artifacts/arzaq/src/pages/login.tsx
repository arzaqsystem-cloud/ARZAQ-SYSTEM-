import { useState } from "react";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUsers, useCurrentUser } from "@/lib/store";
import { LogIn, UserCircle, KeyRound, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Login() {
  const [, setLocation] = useLocation();
  const [users] = useUsers();
  const [, setCurrentUser] = useCurrentUser();
  
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!username || !password) {
      setError("الرجاء إدخال اسم المستخدم وكلمة المرور");
      return;
    }

    const user = users.find(u => u.user === username && u.pass === password);
    
    if (!user) {
      setError("اسم المستخدم أو كلمة المرور غير صحيحة");
      return;
    }

    if (user.status === "frozen") {
      setError("هذا الحساب مجمد، يرجى مراجعة المسؤول");
      return;
    }

    setCurrentUser(user.user);
    setLocation("/app");
  };

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col justify-center items-center p-6 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 -left-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 -right-20 w-64 h-64 bg-secondary/10 rounded-full blur-3xl"></div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md z-10"
      >
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-primary text-primary-foreground rounded-3xl shadow-lg mb-6 rotate-3">
            <LogIn size={36} className="-rotate-3" />
          </div>
          <h1 className="text-4xl font-black tracking-tight text-foreground mb-2">مرحباً بك</h1>
          <p className="text-muted-foreground">سجل دخولك لمتابعة أرزاقك</p>
        </div>

        <form onSubmit={handleLogin} className="bg-card border border-card-border p-6 sm:p-8 rounded-[2rem] shadow-xl space-y-6">
          {error && (
            <Alert variant="destructive" className="animate-in fade-in zoom-in duration-300">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="font-medium ms-2">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-base font-semibold ms-1">اسم المستخدم</Label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none text-muted-foreground">
                  <UserCircle size={20} />
                </div>
                <Input 
                  id="username"
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="ps-10 h-14 rounded-xl bg-muted/50 border-transparent focus:border-primary focus:bg-background text-lg transition-colors"
                  placeholder="أدخل اسم المستخدم"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-base font-semibold ms-1">كلمة المرور</Label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none text-muted-foreground">
                  <KeyRound size={20} />
                </div>
                <Input 
                  id="password"
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="ps-10 h-14 rounded-xl bg-muted/50 border-transparent focus:border-primary focus:bg-background text-lg transition-colors"
                  placeholder="أدخل كلمة المرور"
                  dir="ltr"
                />
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full h-14 text-lg font-bold rounded-xl shadow-md mt-4">
            تسجيل الدخول
          </Button>

          <div className="pt-4 text-center border-t border-border">
            <p className="text-muted-foreground">
              ليس لديك حساب؟{" "}
              <Link href="/register" className="text-primary font-bold hover:underline">
                إنشاء حساب جديد
              </Link>
            </p>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
