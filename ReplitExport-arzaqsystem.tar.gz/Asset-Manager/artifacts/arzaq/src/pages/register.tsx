import { useState } from "react";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUsers } from "@/lib/store";
import { UserPlus, UserCircle, KeyRound, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

export default function Register() {
  const [, setLocation] = useLocation();
  const [users, setUsers] = useUsers();
  const { toast } = useToast();
  
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!username || !password || !confirmPassword) {
      setError("الرجاء تعبئة جميع الحقول");
      return;
    }

    if (password !== confirmPassword) {
      setError("كلمات المرور غير متطابقة");
      return;
    }

    if (users.some(u => u.user === username)) {
      setError("اسم المستخدم موجود مسبقاً، اختر اسماً آخر");
      return;
    }

    setUsers([
      ...users,
      { user: username, pass: password, status: "active", role: "user" },
    ]);
    
    toast({
      title: "تم إنشاء الحساب بنجاح",
      description: "يمكنك الآن تسجيل الدخول باستخدام حسابك الجديد",
    });
    
    setLocation("/login");
  };

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col justify-center items-center p-6 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 -right-20 w-64 h-64 bg-secondary/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 -left-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md z-10"
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-secondary text-secondary-foreground rounded-3xl shadow-lg mb-6 -rotate-3">
            <UserPlus size={36} className="rotate-3" />
          </div>
          <h1 className="text-4xl font-black tracking-tight text-foreground mb-2">حساب جديد</h1>
          <p className="text-muted-foreground">انضم إلى المنظومة لبدء العمل</p>
        </div>

        <form onSubmit={handleRegister} className="bg-card border border-card-border p-6 sm:p-8 rounded-[2rem] shadow-xl space-y-5">
          {error && (
            <Alert variant="destructive" className="animate-in fade-in zoom-in duration-300">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="font-medium ms-2">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-base font-semibold ms-1">اسم المستخدم</Label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none text-muted-foreground">
                  <UserCircle size={20} />
                </div>
                <Input 
                  id="username"
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="ps-10 h-14 rounded-xl bg-muted/50 border-transparent focus:border-primary focus:bg-background text-lg transition-colors"
                  placeholder="أدخل اسم المستخدم"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-base font-semibold ms-1">كلمة المرور</Label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none text-muted-foreground">
                  <KeyRound size={20} />
                </div>
                <Input 
                  id="password"
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="ps-10 h-14 rounded-xl bg-muted/50 border-transparent focus:border-primary focus:bg-background text-lg transition-colors"
                  placeholder="أدخل كلمة المرور"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-base font-semibold ms-1">تأكيد كلمة المرور</Label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none text-muted-foreground">
                  <KeyRound size={20} />
                </div>
                <Input 
                  id="confirmPassword"
                  type="password" 
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="ps-10 h-14 rounded-xl bg-muted/50 border-transparent focus:border-primary focus:bg-background text-lg transition-colors"
                  placeholder="أعد إدخال كلمة المرور"
                  dir="ltr"
                />
              </div>
            </div>
          </div>

          <Button type="submit" variant="secondary" className="w-full h-14 text-lg font-bold rounded-xl shadow-md mt-6">
            إنشاء الحساب
          </Button>

          <div className="pt-4 text-center border-t border-border mt-4">
            <p className="text-muted-foreground">
              لديك حساب بالفعل؟{" "}
              <Link href="/login" className="text-primary font-bold hover:underline">
                سجل الدخول
              </Link>
            </p>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
