import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArzaqMark } from "@/components/arzaq-logo";
import { ArrowLeft } from "lucide-react";

export default function Splash() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center justify-center bg-primary text-primary-foreground p-6 relative overflow-hidden">
      {/* decorative circles */}
      <div className="absolute -top-32 -end-32 w-96 h-96 rounded-full bg-secondary/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -start-32 w-96 h-96 rounded-full bg-white/5 blur-3xl pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center space-y-5 flex-1 justify-center relative z-10"
      >
        <motion.div
          initial={{ scale: 0.8, rotate: -8, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.1, type: "spring" }}
          className="mb-3"
        >
          <ArzaqMark size={120} className="drop-shadow-2xl" />
        </motion.div>

        <h1 className="text-6xl font-black tracking-[0.15em] drop-shadow-sm text-center">
          ARZAQ
        </h1>
        <div className="bg-primary-foreground/10 px-5 py-1.5 rounded-full border border-white/15 backdrop-blur-sm">
          <p className="text-base font-bold tracking-[0.4em] text-primary-foreground/95">
            PRO · ULTRA
          </p>
        </div>
        <p className="text-primary-foreground/80 mt-6 text-center max-w-[280px] leading-relaxed text-base">
          منظومة احترافية لحساب العمولات وتتبع المبيعات اليومية والشهرية
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="w-full max-w-sm pb-8 relative z-10"
      >
        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold bg-white text-primary hover:bg-white/90 shadow-xl rounded-2xl gap-2"
          onClick={() => setLocation("/terms")}
        >
          ابدأ
          <ArrowLeft size={22} />
        </Button>
      </motion.div>
    </div>
  );
}
