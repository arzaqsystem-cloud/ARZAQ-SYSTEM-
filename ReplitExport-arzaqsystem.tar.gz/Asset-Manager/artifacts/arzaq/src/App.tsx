import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Splash from "@/pages/splash";
import Terms from "@/pages/terms";
import Login from "@/pages/login";
import Register from "@/pages/register";
import MainApp from "@/pages/main-app";
import { useTerms, useCurrentUser, useEnsureAdmin } from "@/lib/store";

const queryClient = new QueryClient();

function Router() {
  const [terms] = useTerms();
  const [currentUser] = useCurrentUser();
  useEnsureAdmin();

  return (
    <Switch>
      <Route path="/">
        {terms === "yes" ? (currentUser ? <MainApp /> : <Login />) : <Splash />}
      </Route>
      <Route path="/terms" component={Terms} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/app" component={MainApp} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
