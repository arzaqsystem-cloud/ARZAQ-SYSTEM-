import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Trash2,
  Calendar,
  FileQuestion,
  Printer,
  Filter,
  X,
  ScrollText,
  AlertCircle,
  Share2,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useSales, useBaseSalary, useCurrentUser } from "@/lib/store";
import { formatDistanceToNow, format } from "date-fns";
import { ar } from "date-fns/locale";
import { openPrintReport } from "@/lib/print-report";
import { formatTime12 } from "@/lib/visibility-clock";
import { WhatsappIcon } from "@/components/whatsapp-icon";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

type Period = "all" | "today" | "month";

const PERIOD_LABELS: Record<Period, string> = {
  all: "كل المبيعات",
  today: "مبيعات اليوم",
  month: "مبيعات هذا الشهر",
};

type SaleRow = ReturnType<typeof useSales>[0][number];

export default function HistoryTab() {
  const [sales, setSales] = useSales();
  const [baseSalary] = useBaseSalary();
  const [currentUser] = useCurrentUser();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [period, setPeriod] = useState<Period>("all");
  const [pendingDelete, setPendingDelete] = useState<SaleRow | null>(null);

  const periodFiltered = useMemo(() => {
    if (period === "all") return sales;
    const now = new Date();
    if (period === "today") {
      const todayKey = format(now, "yyyy-MM-dd");
      return sales.filter(
        (s) => format(new Date(s.date), "yyyy-MM-dd") === todayKey,
      );
    }
    const monthKey = format(now, "yyyy-MM");
    return sales.filter(
      (s) => format(new Date(s.date), "yyyy-MM") === monthKey,
    );
  }, [sales, period]);

  const filteredSales = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return periodFiltered;
    return periodFiltered.filter(
      (s) =>
        s.productName.toLowerCase().includes(q) ||
        (s.company || "").toLowerCase().includes(q),
    );
  }, [periodFiltered, search]);

  const totals = useMemo(() => {
    const total = filteredSales.reduce((acc, s) => acc + s.commission, 0);
    return { total, count: filteredSales.length };
  }, [filteredSales]);

  const confirmDelete = () => {
    if (!pendingDelete) return;
    setSales(sales.filter((s) => s.id !== pendingDelete.id));
    toast({
      description: `تم حذف عملية بيع: ${pendingDelete.productName}`,
    });
    setPendingDelete(null);
  };

  const formatRelDate = (dateStr: string) => {
    try {
      return formatDistanceToNow(new Date(dateStr), {
        addSuffix: true,
        locale: ar,
      });
    } catch {
      return "تاريخ غير معروف";
    }
  };

  const handlePrint = () => {
    openPrintReport({
      sales: filteredSales,
      baseSalary,
      username: currentUser,
      generatedAt: new Date(),
      filterLabel: `${PERIOD_LABELS[period]}${search ? ` — بحث: "${search}"` : ""}`,
    });
  };

  const handleShareWhatsapp = () => {
    const totalQty = filteredSales.reduce(
      (a, s) => a + (s.quantity ?? 1),
      0,
    );
    const projected = totals.total + baseSalary;
    const today = format(new Date(), "yyyy-MM-dd");
    const filter = `${PERIOD_LABELS[period]}${search ? ` — بحث: "${search}"` : ""}`;

    const lines = [
      "🌿 *ARZAQ PRO ULTRA*",
      "📋 *تقرير المبيعات والعمولات*",
      "━━━━━━━━━━━━━━━",
      `👤 الموظف: *${currentUser ?? "—"}*`,
      `📅 تاريخ التقرير: ${today}`,
      `🔍 الفلتر: ${filter}`,
      "",
      "📊 *الإحصائيات*",
      `🧾 عدد العمليات: *${totals.count}*`,
      `📦 إجمالي القطع: *${totalQty}*`,
      `💰 إجمالي العمولات: *${totals.total.toFixed(2)} د.ل*`,
      `🏦 الراتب الأساسي: ${baseSalary.toFixed(2)} د.ل`,
      "━━━━━━━━━━━━━━━",
      `✨ *الراتب الإجمالي المتوقع:*`,
      `💎 *${projected.toFixed(2)} د.ل*`,
      "",
      "_⚠️ ملاحظة: هذه الأرقام تقديرية للمتابعة الشخصية فقط ولا تعتمد كوثيقة رسمية أو قانونية._",
      "",
      "— ARZAQ PRO ULTRA",
    ];

    const text = encodeURIComponent(lines.join("\n"));
    const url = `https://wa.me/?text=${text}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="p-4 space-y-3 flex flex-col">
      {/* Smart search bar */}
      <div className="relative">
        <div className="absolute inset-y-0 start-0 flex items-center ps-4 pointer-events-none text-muted-foreground">
          <Search size={18} />
        </div>
        <Input
          placeholder="ابحث باسم المنتج أو الشركة..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-12 ps-11 pe-10 rounded-xl bg-card border-card-border shadow-sm text-sm"
        />
        {search && (
          <button
            onClick={() => setSearch("")}
            className="absolute inset-y-0 end-0 flex items-center pe-4 text-muted-foreground hover:text-foreground"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Period filter chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        <Filter size={14} className="text-muted-foreground flex-shrink-0" />
        {(Object.keys(PERIOD_LABELS) as Period[]).map((p) => {
          const active = period === p;
          return (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-colors border ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground border-card-border hover:text-foreground"
              }`}
            >
              {PERIOD_LABELS[p]}
            </button>
          );
        })}
      </div>

      {/* Summary + share/print bar */}
      <div className="bg-gradient-to-br from-primary/10 to-secondary/5 border border-primary/20 rounded-2xl p-3 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex flex-col leading-tight">
            <span className="text-[11px] text-muted-foreground font-bold">
              إجمالي العمولات للنتائج المعروضة
            </span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-xl font-black text-primary tabular-nums">
                {totals.total.toFixed(2)}
              </span>
              <span className="text-[10px] font-bold text-muted-foreground">
                د.ل
              </span>
              <span className="text-[10px] text-muted-foreground ms-2">
                · {totals.count} عملية
              </span>
            </div>
          </div>
          <div className="text-end">
            <span className="text-[10px] text-muted-foreground font-bold">
              الراتب المتوقع
            </span>
            <div className="text-base font-black text-emerald-600 tabular-nums leading-tight">
              {(totals.total + baseSalary).toFixed(2)}
              <span className="text-[9px] text-muted-foreground font-bold ms-0.5">
                د.ل
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={handlePrint}
            disabled={filteredSales.length === 0}
            className="h-11 rounded-xl gap-2 font-bold shadow-sm"
          >
            <Printer size={15} />
            طباعة التقرير
          </Button>
          <button
            onClick={handleShareWhatsapp}
            disabled={filteredSales.length === 0}
            className="h-11 rounded-xl flex items-center justify-center gap-2 font-bold text-white bg-[#25D366] hover:bg-[#20bd5b] active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none transition-all shadow-sm"
          >
            <WhatsappIcon size={18} />
            مشاركة واتساب
            <Share2 size={13} className="opacity-80" />
          </button>
        </div>
      </div>

      {/* Permanent legal disclaimer (always visible, never dismissible) */}
      <div className="bg-gradient-to-br from-rose-50 to-amber-50 border-2 border-rose-200 rounded-2xl p-3 flex gap-2.5 shadow-sm">
        <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center mt-0.5">
          <ScrollText size={16} strokeWidth={2.4} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] font-black text-rose-700 mb-1 tracking-wider">
            تنبيه قانوني هام · غير قابل للإغلاق
          </p>
          <p className="text-[11px] leading-relaxed text-rose-900 font-semibold">
            لا يعتد بهذه النتائج كوثائق رسمية أو قانونية في أي نزاعات أو
            معاملات مالية ملزمة. نحن غير مسؤولين عن أي فروقات أو أخطاء قد
            تترتب على استخدام هذه التقديرات في غير الغرض المخصص لها.
          </p>
        </div>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 -mx-1 px-1">
        {sales.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center h-64 text-muted-foreground"
          >
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
              <FileQuestion size={32} className="opacity-50" />
            </div>
            <p className="font-medium text-lg">لا توجد مبيعات مسجلة بعد</p>
            <p className="text-sm opacity-80 mt-1">
              أضف مبيعات من قسم المبيعات
            </p>
          </motion.div>
        ) : filteredSales.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground bg-card border border-card-border rounded-2xl">
            لا توجد نتائج تطابق الفلاتر الحالية
          </div>
        ) : (
          <div className="space-y-2.5 pb-2">
            <AnimatePresence initial={false}>
              {filteredSales.map((sale) => {
                const d = new Date(sale.date);
                const qty = sale.quantity ?? 1;
                return (
                  <motion.div
                    key={sale.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, height: 0 }}
                    transition={{ duration: 0.15 }}
                    className="bg-card border border-card-border p-3 rounded-2xl shadow-sm flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-11 h-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-black flex-shrink-0 relative">
                        {sale.productName.substring(0, 1).toUpperCase()}
                        {qty > 1 && (
                          <span className="absolute -top-1.5 -end-1.5 min-w-[20px] h-5 px-1 bg-secondary text-secondary-foreground rounded-full text-[10px] font-black flex items-center justify-center shadow">
                            ×{qty}
                          </span>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="font-bold text-foreground text-base leading-tight truncate">
                          {sale.productName}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                          {sale.company && (
                            <span className="text-[10px] font-bold bg-secondary/15 text-secondary px-1.5 py-0.5 rounded">
                              {sale.company}
                            </span>
                          )}
                          <span className="flex items-center gap-1 text-muted-foreground text-[10px]">
                            <Calendar size={10} />
                            {formatRelDate(sale.date)}
                          </span>
                          <span className="text-muted-foreground text-[10px] tabular-nums">
                            · {formatTime12(d, false)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="text-end">
                        <div className="font-black text-primary text-base tabular-nums">
                          +{sale.commission.toFixed(2)}
                        </div>
                        <div className="text-[9px] font-bold text-muted-foreground">
                          د.ل عمولة
                        </div>
                      </div>
                      <button
                        onClick={() => setPendingDelete(sale)}
                        className="w-8 h-8 flex items-center justify-center text-destructive/50 hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                        aria-label="حذف"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Delete confirmation with the operation name */}
      <AlertDialog
        open={!!pendingDelete}
        onOpenChange={(open) => !open && setPendingDelete(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle /> تأكيد حذف عملية البيع
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right text-base">
              هل أنت متأكد من حذف العملية التالية؟ لا يمكن التراجع.
            </AlertDialogDescription>
          </AlertDialogHeader>

          {pendingDelete && (
            <div className="bg-muted/40 rounded-2xl p-3 space-y-1.5 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-bold text-muted-foreground">المنتج</span>
                <span className="font-black">{pendingDelete.productName}</span>
              </div>
              {pendingDelete.company && (
                <div className="flex items-center justify-between">
                  <span className="font-bold text-muted-foreground">الشركة</span>
                  <span className="font-black bg-secondary/15 text-secondary px-2 py-0.5 rounded text-xs">
                    {pendingDelete.company}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="font-bold text-muted-foreground">الكمية</span>
                <span className="font-black">
                  {pendingDelete.quantity ?? 1}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-muted-foreground">
                  العمولة
                </span>
                <span className="font-black text-primary tabular-nums">
                  {pendingDelete.commission.toFixed(2)} د.ل
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-muted-foreground">
                  التاريخ
                </span>
                <span className="font-bold tabular-nums text-xs">
                  {format(new Date(pendingDelete.date), "yyyy-MM-dd")} ·{" "}
                  {formatTime12(new Date(pendingDelete.date), false)}
                </span>
              </div>
            </div>
          )}

          <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0 h-12 rounded-xl">
              إلغاء
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 h-12 rounded-xl"
            >
              نعم، احذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
