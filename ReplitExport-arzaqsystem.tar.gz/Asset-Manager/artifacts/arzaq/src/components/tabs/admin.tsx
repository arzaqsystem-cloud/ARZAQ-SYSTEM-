import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  BarChart3,
  TrendingUp,
  Users,
  Crown,
  Award,
  Calculator,
  CalendarRange,
  Trophy,
  ChevronDown,
  Sparkles,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
} from "recharts";
import {
  useUsers,
  useAllUserSales,
  useAllUserBaseSalaries,
  useCurrentUser,
} from "@/lib/store";
import { format, subDays, startOfDay } from "date-fns";
import { ar } from "date-fns/locale";

const PALETTE = [
  "#0d3b2e",
  "#d4a64a",
  "#0f766e",
  "#b45309",
  "#15803d",
  "#7c2d12",
  "#1e40af",
  "#9333ea",
  "#be123c",
];

export default function AdminTab() {
  const [users] = useUsers();
  const [currentUser] = useCurrentUser();
  const usernames = useMemo(() => users.map((u) => u.user), [users]);
  const allSales = useAllUserSales(usernames);
  const allBase = useAllUserBaseSalaries(usernames);

  const [selectedUser, setSelectedUser] = useState<string>("__all__");

  const activeSales = useMemo(() => {
    if (selectedUser === "__all__") {
      return Object.values(allSales).flat();
    }
    return allSales[selectedUser] || [];
  }, [allSales, selectedUser]);

  const baseSalary = useMemo(() => {
    if (selectedUser === "__all__") {
      return Object.values(allBase).reduce((a, b) => a + b, 0);
    }
    return allBase[selectedUser] ?? 0;
  }, [allBase, selectedUser]);

  /* ================= AGGREGATES ================= */

  const monthKey = format(new Date(), "yyyy-MM");
  const monthSales = useMemo(
    () => activeSales.filter((s) => format(new Date(s.date), "yyyy-MM") === monthKey),
    [activeSales, monthKey],
  );

  const monthCommission = useMemo(
    () => monthSales.reduce((a, s) => a + s.commission, 0),
    [monthSales],
  );

  /* Approx salary = average commission per active day × 26 + base salary */
  const projection = useMemo(() => {
    const dayBuckets = new Map<string, number>();
    monthSales.forEach((s) => {
      const k = format(new Date(s.date), "yyyy-MM-dd");
      dayBuckets.set(k, (dayBuckets.get(k) || 0) + s.commission);
    });
    const activeDays = dayBuckets.size;
    const avgPerActiveDay = activeDays > 0 ? monthCommission / activeDays : 0;
    const approxMonthly = avgPerActiveDay * 26;
    return {
      activeDays,
      avgPerActiveDay,
      approxMonthly,
      approxTotal: approxMonthly + baseSalary,
    };
  }, [monthSales, monthCommission, baseSalary]);

  /* Best company chart */
  const companyData = useMemo(() => {
    const map = new Map<string, { name: string; commission: number; count: number }>();
    activeSales.forEach((s) => {
      const c = s.company || "—";
      const cur = map.get(c) || { name: c, commission: 0, count: 0 };
      cur.commission += s.commission;
      cur.count += 1;
      map.set(c, cur);
    });
    return Array.from(map.values())
      .sort((a, b) => b.commission - a.commission)
      .slice(0, 8);
  }, [activeSales]);

  /* Best products chart */
  const productData = useMemo(() => {
    const map = new Map<string, { name: string; commission: number; count: number }>();
    activeSales.forEach((s) => {
      const k = s.productName;
      const cur = map.get(k) || { name: k, commission: 0, count: 0 };
      cur.commission += s.commission;
      cur.count += s.quantity ?? 1;
      map.set(k, cur);
    });
    return Array.from(map.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);
  }, [activeSales]);

  /* Last 7 days comparison */
  const last7Days = useMemo(() => {
    const days: { label: string; key: string; commission: number; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = startOfDay(subDays(new Date(), i));
      const key = format(d, "yyyy-MM-dd");
      days.push({
        label: format(d, "EEE", { locale: ar }),
        key,
        commission: 0,
        count: 0,
      });
    }
    activeSales.forEach((s) => {
      const k = format(new Date(s.date), "yyyy-MM-dd");
      const day = days.find((dd) => dd.key === k);
      if (day) {
        day.commission += s.commission;
        day.count += 1;
      }
    });
    return days;
  }, [activeSales]);

  /* Per-user breakdown for the team */
  const teamRows = useMemo(() => {
    return usernames.map((u) => {
      const sales = allSales[u] || [];
      const totalComm = sales.reduce((a, s) => a + s.commission, 0);
      const monthComm = sales
        .filter((s) => format(new Date(s.date), "yyyy-MM") === monthKey)
        .reduce((a, s) => a + s.commission, 0);
      const userBase = allBase[u] ?? 0;
      return {
        user: u,
        operations: sales.length,
        totalComm,
        monthComm,
        baseSalary: userBase,
        projected: monthComm + userBase,
      };
    });
  }, [usernames, allSales, allBase, monthKey]);

  const topCompany = companyData[0];
  const topProduct = productData[0];

  return (
    <div className="p-4 space-y-5">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-primary via-primary to-primary/80 text-primary-foreground p-5 rounded-3xl shadow-lg relative overflow-hidden"
      >
        <div className="absolute -top-10 -end-10 w-40 h-40 bg-secondary/20 rounded-full blur-3xl" />
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center">
            <Crown size={24} className="text-secondary" />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-black tracking-wide">لوحة المسؤول</h2>
            <p className="text-xs opacity-80 mt-0.5">
              نظرة شاملة على أداء الفريق
            </p>
          </div>
          <Sparkles size={20} className="text-secondary opacity-80" />
        </div>
      </motion.div>

      {/* User selector */}
      <div className="bg-card border border-card-border rounded-2xl p-3 flex items-center gap-2 shadow-sm">
        <Users size={18} className="text-secondary flex-shrink-0" />
        <div className="text-xs font-bold text-muted-foreground flex-shrink-0">
          عرض البيانات لـ
        </div>
        <div className="relative flex-1 min-w-0">
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="w-full appearance-none bg-muted/40 rounded-xl h-10 px-3 pe-9 text-sm font-bold border border-input outline-none focus:ring-2 focus:ring-primary/30 cursor-pointer truncate"
          >
            <option value="__all__">جميع الموظفين (الفريق كاملاً)</option>
            {usernames.map((u) => (
              <option key={u} value={u}>
                {u}
                {u === currentUser ? " · أنت" : ""}
              </option>
            ))}
          </select>
          <ChevronDown
            size={14}
            className="absolute end-3 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground"
          />
        </div>
      </div>

      {/* Salary projection */}
      <div className="bg-card border-2 border-emerald-500/20 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 flex items-center justify-center">
            <Calculator size={18} />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-bold">الراتب التقريبي للشهر</h3>
            <p className="text-[11px] text-muted-foreground">
              متوسط عمولات اليوم × ٢٦ يوم + الراتب الأساسي
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-1">
          <Stat
            label="أيام نشاط"
            value={projection.activeDays.toString()}
            unit="يوم"
            tone="muted"
          />
          <Stat
            label="متوسط يومي"
            value={projection.avgPerActiveDay.toFixed(1)}
            unit="د.ل"
            tone="primary"
          />
          <Stat
            label="عمولات تقديرية × ٢٦"
            value={projection.approxMonthly.toFixed(1)}
            unit="د.ل"
            tone="secondary"
          />
        </div>

        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white rounded-2xl p-4 flex items-center justify-between shadow-lg shadow-emerald-500/25">
          <div className="flex flex-col leading-tight">
            <span className="text-[11px] opacity-80 font-bold">
              الراتب الإجمالي المتوقع
            </span>
            <span className="text-[10px] opacity-70 mt-0.5">
              (راتب أساسي {baseSalary.toFixed(0)} + تقدير العمولات)
            </span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-black tabular-nums">
              {projection.approxTotal.toFixed(2)}
            </span>
            <span className="text-xs font-bold opacity-80">د.ل</span>
          </div>
        </div>
      </div>

      {/* Top company / Top product highlight */}
      {(topCompany || topProduct) && (
        <div className="grid grid-cols-2 gap-3">
          {topCompany && (
            <HighlightCard
              icon={Trophy}
              label="أفضل شركة مبيعات"
              title={topCompany.name}
              value={`${topCompany.commission.toFixed(0)} د.ل`}
              sub={`${topCompany.count} عملية`}
              color="primary"
            />
          )}
          {topProduct && (
            <HighlightCard
              icon={Award}
              label="الأكثر مبيعاً"
              title={topProduct.name}
              value={`${topProduct.count} قطعة`}
              sub={`${topProduct.commission.toFixed(0)} د.ل عمولات`}
              color="secondary"
            />
          )}
        </div>
      )}

      {/* Best company chart */}
      <ChartCard
        icon={BarChart3}
        title="مبيعات الشركات (د.ل)"
        empty={companyData.length === 0}
      >
        <ResponsiveContainer width="100%" height={220}>
          <BarChart
            data={companyData}
            margin={{ top: 5, right: 10, left: -10, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 10, fontWeight: "bold" }}
              interval={0}
              angle={-25}
              textAnchor="end"
              height={50}
            />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip
              cursor={{ fill: "rgba(13, 59, 46, 0.06)" }}
              contentStyle={{
                borderRadius: 12,
                border: "1px solid #e5e7eb",
                fontSize: 12,
                fontFamily: "inherit",
              }}
              formatter={(v: any) => [`${(+v).toFixed(2)} د.ل`, "العمولات"]}
            />
            <Bar dataKey="commission" radius={[8, 8, 0, 0]}>
              {companyData.map((_, i) => (
                <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Best product chart */}
      <ChartCard
        icon={Award}
        title="أكثر الأصناف مبيعاً (قطعة)"
        empty={productData.length === 0}
      >
        <ResponsiveContainer width="100%" height={240}>
          <BarChart
            data={productData}
            layout="vertical"
            margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e5e7eb" />
            <XAxis type="number" tick={{ fontSize: 10 }} />
            <YAxis
              type="category"
              dataKey="name"
              tick={{ fontSize: 10, fontWeight: "bold" }}
              width={100}
            />
            <Tooltip
              cursor={{ fill: "rgba(212, 166, 74, 0.06)" }}
              contentStyle={{
                borderRadius: 12,
                border: "1px solid #e5e7eb",
                fontSize: 12,
              }}
              formatter={(v: any, key: any) => [
                key === "count" ? `${v} قطعة` : `${(+v).toFixed(2)} د.ل`,
                key === "count" ? "عدد القطع" : "العمولات",
              ]}
            />
            <Bar dataKey="count" radius={[0, 8, 8, 0]} fill="#d4a64a" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Last 7 days comparison */}
      <ChartCard
        icon={CalendarRange}
        title="مقارنة آخر ٧ أيام"
        empty={last7Days.every((d) => d.count === 0)}
      >
        <ResponsiveContainer width="100%" height={200}>
          <BarChart
            data={last7Days}
            margin={{ top: 5, right: 10, left: -10, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
            <XAxis dataKey="label" tick={{ fontSize: 10, fontWeight: "bold" }} />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip
              cursor={{ fill: "rgba(13, 59, 46, 0.06)" }}
              contentStyle={{
                borderRadius: 12,
                border: "1px solid #e5e7eb",
                fontSize: 12,
              }}
              formatter={(v: any) => [`${(+v).toFixed(2)} د.ل`, "عمولات"]}
            />
            <Bar dataKey="commission" radius={[8, 8, 0, 0]} fill="#0d3b2e" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Team breakdown */}
      <div className="bg-card border border-card-border rounded-3xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-card-border flex items-center gap-2">
          <Users size={18} className="text-secondary" />
          <h3 className="font-bold">أداء الفريق هذا الشهر</h3>
        </div>
        <div className="divide-y divide-border">
          {teamRows.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground text-sm">
              لا يوجد موظفون بعد
            </div>
          ) : (
            teamRows
              .sort((a, b) => b.monthComm - a.monthComm)
              .map((r, idx) => (
                <div
                  key={r.user}
                  className="p-3 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0 ${
                        idx === 0
                          ? "bg-secondary text-secondary-foreground"
                          : "bg-primary/10 text-primary"
                      }`}
                    >
                      {idx === 0 ? <Crown size={16} /> : idx + 1}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-sm truncate">
                        {r.user}
                        {r.user === currentUser && (
                          <span className="ms-1.5 text-[9px] bg-primary/15 text-primary px-1.5 py-0.5 rounded font-black">
                            أنت
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {r.operations} عملية إجمالاً
                      </div>
                    </div>
                  </div>
                  <div className="text-end flex-shrink-0">
                    <div className="font-black text-primary text-sm tabular-nums flex items-baseline gap-1 justify-end">
                      <span>{r.monthComm.toFixed(2)}</span>
                      <span className="text-[9px] text-muted-foreground font-bold">
                        د.ل
                      </span>
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      راتب متوقع{" "}
                      <span className="font-black text-emerald-600">
                        {r.projected.toFixed(0)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  unit,
  tone,
}: {
  label: string;
  value: string;
  unit: string;
  tone: "primary" | "secondary" | "muted";
}) {
  const toneMap = {
    primary: "text-primary",
    secondary: "text-secondary",
    muted: "text-foreground",
  };
  return (
    <div className="bg-muted/30 rounded-xl p-2.5 text-center">
      <div className="text-[10px] font-bold text-muted-foreground mb-1 truncate">
        {label}
      </div>
      <div className={`text-base font-black tabular-nums ${toneMap[tone]}`}>
        {value}
      </div>
      <div className="text-[9px] text-muted-foreground font-bold">{unit}</div>
    </div>
  );
}

function HighlightCard({
  icon: Icon,
  label,
  title,
  value,
  sub,
  color,
}: {
  icon: any;
  label: string;
  title: string;
  value: string;
  sub: string;
  color: "primary" | "secondary";
}) {
  const map = {
    primary: "from-primary/10 to-primary/5 border-primary/20 text-primary",
    secondary: "from-secondary/15 to-secondary/5 border-secondary/30 text-secondary",
  };
  return (
    <div
      className={`bg-gradient-to-br ${map[color]} border rounded-2xl p-3 shadow-sm`}
    >
      <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black tracking-wider opacity-90">
        <Icon size={12} />
        {label}
      </div>
      <div className="font-black text-sm truncate text-foreground">{title}</div>
      <div className="font-black text-base tabular-nums mt-0.5">{value}</div>
      <div className="text-[10px] text-muted-foreground font-bold mt-0.5">{sub}</div>
    </div>
  );
}

function ChartCard({
  icon: Icon,
  title,
  empty,
  children,
}: {
  icon: any;
  title: string;
  empty: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-card border border-card-border rounded-3xl shadow-sm overflow-hidden">
      <div className="p-3 border-b border-card-border flex items-center gap-2">
        <Icon size={16} className="text-primary" />
        <h3 className="font-bold text-sm">{title}</h3>
        <TrendingUp size={12} className="text-muted-foreground ms-auto" />
      </div>
      {empty ? (
        <div className="p-8 text-center text-muted-foreground text-sm">
          لا توجد بيانات كافية بعد
        </div>
      ) : (
        <div className="p-2 pt-3" dir="ltr">
          {children}
        </div>
      )}
    </div>
  );
}
