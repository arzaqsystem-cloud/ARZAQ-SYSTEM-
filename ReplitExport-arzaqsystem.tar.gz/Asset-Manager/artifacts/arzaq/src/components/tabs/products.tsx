import { useMemo, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  PackagePlus,
  Trash2,
  AlertCircle,
  Percent,
  Hash,
  Building2,
  RotateCcw,
  Search,
  X,
  Pencil,
  Save,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useProducts, DEFAULT_PRODUCTS, type Product } from "@/lib/store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

const NEW_COMPANY_VALUE = "__new__";

export default function ProductsTab() {
  const [products, setProducts] = useProducts();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [comm, setComm] = useState("");
  const [type, setType] = useState<"fixed" | "percent">("fixed");
  const [companyChoice, setCompanyChoice] = useState<string>("");
  const [newCompany, setNewCompany] = useState("");
  const [search, setSearch] = useState("");

  const [editing, setEditing] = useState<Product | null>(null);
  const [editName, setEditName] = useState("");
  const [editComm, setEditComm] = useState("");
  const [editType, setEditType] = useState<"fixed" | "percent">("fixed");

  useEffect(() => {
    if (editing) {
      setEditName(editing.name);
      setEditComm(String(editing.comm));
      setEditType(editing.type);
    }
  }, [editing]);

  const handleSaveEdit = () => {
    if (!editing) return;
    if (!editName.trim()) {
      toast({ variant: "destructive", description: "اسم الصنف لا يمكن أن يكون فارغاً" });
      return;
    }
    const commVal = parseFloat(editComm);
    if (isNaN(commVal) || commVal < 0) {
      toast({ variant: "destructive", description: "قيمة العمولة غير صحيحة" });
      return;
    }
    if (editType === "percent" && commVal > 100) {
      toast({ variant: "destructive", description: "النسبة لا يمكن أن تتجاوز 100٪" });
      return;
    }
    setProducts(
      products.map((p) =>
        p.id === editing.id
          ? { ...p, name: editName.trim(), comm: commVal, type: editType }
          : p,
      ),
    );
    toast({ description: "تم حفظ التعديلات بنجاح" });
    setEditing(null);
  };

  const existingCompanies = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => set.add(p.company));
    return Array.from(set);
  }, [products]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return products;
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.company.toLowerCase().includes(q),
    );
  }, [products, search]);

  const grouped = useMemo(() => {
    const map = new Map<string, typeof products>();
    filtered.forEach((p) => {
      if (!map.has(p.company)) map.set(p.company, []);
      map.get(p.company)!.push(p);
    });
    return Array.from(map.entries());
  }, [filtered]);

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCompany =
      companyChoice === NEW_COMPANY_VALUE
        ? newCompany.trim().toUpperCase()
        : companyChoice.trim();

    if (!finalCompany) {
      toast({ variant: "destructive", description: "الرجاء اختيار أو كتابة اسم الشركة" });
      return;
    }
    if (!name.trim()) {
      toast({ variant: "destructive", description: "الرجاء إدخال اسم الصنف" });
      return;
    }
    if (!comm) {
      toast({ variant: "destructive", description: "الرجاء إدخال قيمة العمولة" });
      return;
    }

    const commVal = parseFloat(comm);
    if (isNaN(commVal) || commVal < 0) {
      toast({ variant: "destructive", description: "قيمة العمولة غير صحيحة" });
      return;
    }
    if (type === "percent" && commVal > 100) {
      toast({ variant: "destructive", description: "النسبة لا يمكن أن تتجاوز 100٪" });
      return;
    }

    const newProduct = {
      id: crypto.randomUUID(),
      name: name.trim(),
      company: finalCompany,
      comm: commVal,
      type,
    };

    setProducts([newProduct, ...products]);
    setName("");
    setComm("");
    setNewCompany("");
    toast({ description: "تمت إضافة الصنف بنجاح" });
  };

  const handleDelete = (id: string) => {
    setProducts(products.filter((p) => p.id !== id));
    toast({ description: "تم حذف الصنف" });
  };

  const handleResetDefaults = () => {
    setProducts(DEFAULT_PRODUCTS);
    toast({ description: "تم استعادة الأصناف الافتراضية" });
  };

  return (
    <div className="p-4 space-y-6">
      <motion.form
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={handleAddProduct}
        className="bg-card border border-card-border p-5 rounded-3xl shadow-md space-y-4"
      >
        <h2 className="text-lg font-bold mb-1 flex items-center gap-2">
          <PackagePlus className="text-secondary" size={20} />
          إضافة صنف جديد
        </h2>

        <div className="space-y-4">
          {/* Company picker */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5 text-sm">
              <Building2 size={14} className="text-muted-foreground" />
              الشركة
            </Label>
            <Select value={companyChoice} onValueChange={setCompanyChoice}>
              <SelectTrigger className="h-12 rounded-xl bg-muted/30">
                <SelectValue placeholder="اختر شركة موجودة أو أضف جديدة" />
              </SelectTrigger>
              <SelectContent>
                {existingCompanies.map((c) => (
                  <SelectItem key={c} value={c} className="font-bold">
                    {c}
                  </SelectItem>
                ))}
                <SelectItem value={NEW_COMPANY_VALUE} className="text-primary font-bold">
                  + شركة جديدة
                </SelectItem>
              </SelectContent>
            </Select>
            {companyChoice === NEW_COMPANY_VALUE && (
              <Input
                value={newCompany}
                onChange={(e) => setNewCompany(e.target.value)}
                placeholder="اسم الشركة الجديدة"
                className="h-12 rounded-xl bg-muted/30 mt-2"
              />
            )}
          </div>

          {/* Product name */}
          <div className="space-y-2">
            <Label className="text-sm">اسم الصنف</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-xl bg-muted/30"
              placeholder="مثال: SPARK 40 PRO"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label className="text-sm">نوع العمولة</Label>
              <div className="flex bg-muted/30 p-1 rounded-xl h-12">
                <button
                  type="button"
                  onClick={() => setType("fixed")}
                  className={`flex-1 flex items-center justify-center gap-1 text-sm font-bold rounded-lg transition-all ${type === "fixed" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <Hash size={14} /> ثابت
                </button>
                <button
                  type="button"
                  onClick={() => setType("percent")}
                  className={`flex-1 flex items-center justify-center gap-1 text-sm font-bold rounded-lg transition-all ${type === "percent" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <Percent size={14} /> نسبة
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">القيمة</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={comm}
                  onChange={(e) => setComm(e.target.value)}
                  className="h-12 rounded-xl bg-muted/30 ps-12"
                  placeholder="0"
                  dir="ltr"
                />
                <div className="absolute inset-y-0 start-4 flex items-center pointer-events-none font-bold text-muted-foreground text-sm">
                  {type === "fixed" ? "د.ل" : "٪"}
                </div>
              </div>
            </div>
          </div>

          <Button
            type="submit"
            variant="secondary"
            className="w-full h-12 font-bold rounded-xl mt-1"
          >
            إضافة الصنف
          </Button>
        </div>
      </motion.form>

      <div className="space-y-4">
        <div className="relative">
          <div className="absolute inset-y-0 start-0 flex items-center ps-4 pointer-events-none text-muted-foreground">
            <Search size={18} />
          </div>
          <Input
            placeholder="ابحث باسم الصنف أو الشركة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-12 ps-11 pe-10 rounded-xl bg-card border-card-border shadow-sm text-sm"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute inset-y-0 end-0 flex items-center pe-4 text-muted-foreground hover:text-foreground"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <div className="flex items-center justify-between px-1">
          <h3 className="font-bold text-muted-foreground text-sm">
            {search
              ? `نتائج البحث (${filtered.length}/${products.length})`
              : `الأصناف الحالية (${products.length})`}
          </h3>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="text-xs font-bold text-muted-foreground hover:text-foreground flex items-center gap-1">
                <RotateCcw size={12} />
                إعادة الافتراضي
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="rounded-3xl">
              <AlertDialogHeader>
                <AlertDialogTitle>استعادة الأصناف الافتراضية</AlertDialogTitle>
                <AlertDialogDescription className="text-right">
                  سيتم استبدال قائمة الأصناف الحالية بالأصناف الافتراضية المحملة في المنظومة. أي إضافات أو تعديلات قمت بها ستفقد. هل تريد المتابعة؟
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
                <AlertDialogCancel className="mt-0 h-12 rounded-xl">
                  إلغاء
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleResetDefaults}
                  className="h-12 rounded-xl"
                >
                  استعادة
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground bg-card border border-card-border rounded-2xl">
            لا توجد أصناف مضافة
          </div>
        ) : grouped.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground bg-card border border-card-border rounded-2xl">
            لا توجد نتائج تطابق بحثك
          </div>
        ) : (
          grouped.map(([company, items]) => (
            <div key={company} className="space-y-2">
              <div className="flex items-center gap-2 px-1">
                <Building2 size={14} className="text-secondary" />
                <h4 className="font-black text-sm tracking-wider">{company}</h4>
                <span className="text-[10px] text-muted-foreground font-bold">
                  ({items.length})
                </span>
                <div className="flex-1 h-px bg-border ms-2" />
              </div>
              <div className="space-y-2">
                <AnimatePresence>
                  {items.map((p) => (
                    <motion.div
                      key={p.id}
                      initial={{ opacity: 0, scale: 0.97 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                      className="bg-card border border-card-border p-3 rounded-2xl flex items-center justify-between shadow-sm overflow-hidden"
                    >
                      <div className="min-w-0 flex-1">
                        <h4 className="font-bold text-base truncate">
                          {p.name}
                        </h4>
                        <div className="flex items-center gap-1 text-primary font-bold bg-primary/10 px-2 py-0.5 rounded-md text-xs mt-1 w-fit">
                          {p.type === "fixed" ? (
                            <>
                              <Hash size={10} /> {p.comm} د.ل
                            </>
                          ) : (
                            <>
                              <Percent size={10} /> {p.comm}٪
                            </>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => setEditing(p)}
                        className="w-9 h-9 flex items-center justify-center text-secondary/80 hover:text-secondary hover:bg-secondary/10 rounded-xl transition-colors flex-shrink-0"
                        aria-label="تعديل"
                      >
                        <Pencil size={17} />
                      </button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <button className="w-9 h-9 flex items-center justify-center text-destructive/70 hover:text-destructive hover:bg-destructive/10 rounded-xl transition-colors flex-shrink-0">
                            <Trash2 size={18} />
                          </button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="rounded-3xl">
                          <AlertDialogHeader>
                            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
                              <AlertCircle /> تأكيد الحذف
                            </AlertDialogTitle>
                            <AlertDialogDescription className="text-base text-right">
                              هل أنت متأكد من حذف صنف "{p.name}" من شركة{" "}
                              {p.company}؟
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
                            <AlertDialogCancel className="mt-0 h-12 rounded-xl">
                              إلغاء
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(p.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 h-12 rounded-xl"
                            >
                              نعم، احذف
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="rounded-3xl max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-secondary text-lg">
              <Pencil size={18} />
              تعديل الصنف
            </DialogTitle>
          </DialogHeader>

          {editing && (
            <div className="space-y-4 pt-2">
              <div className="bg-muted/30 rounded-xl px-3 py-2 flex items-center gap-2 text-xs">
                <Building2 size={13} className="text-secondary" />
                <span className="font-bold text-muted-foreground">الشركة:</span>
                <span className="font-black tracking-wider">{editing.company}</span>
              </div>

              <div className="space-y-2">
                <Label className="text-sm">اسم الصنف</Label>
                <Input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="h-12 rounded-xl bg-muted/30"
                  placeholder="اسم الصنف"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-sm">نوع العمولة</Label>
                  <div className="flex bg-muted/30 p-1 rounded-xl h-12">
                    <button
                      type="button"
                      onClick={() => setEditType("fixed")}
                      className={`flex-1 flex items-center justify-center gap-1 text-sm font-bold rounded-lg transition-all ${editType === "fixed" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      <Hash size={14} /> ثابت
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditType("percent")}
                      className={`flex-1 flex items-center justify-center gap-1 text-sm font-bold rounded-lg transition-all ${editType === "percent" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      <Percent size={14} /> نسبة
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm">القيمة</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      value={editComm}
                      onChange={(e) => setEditComm(e.target.value)}
                      className="h-12 rounded-xl bg-muted/30 ps-12"
                      placeholder="0"
                      dir="ltr"
                    />
                    <div className="absolute inset-y-0 start-4 flex items-center pointer-events-none font-bold text-muted-foreground text-sm">
                      {editType === "fixed" ? "د.ل" : "٪"}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2 pt-2">
            <Button
              variant="outline"
              onClick={() => setEditing(null)}
              className="h-12 rounded-xl flex-1"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleSaveEdit}
              className="h-12 rounded-xl flex-1 gap-2 font-bold"
            >
              <Save size={16} />
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
