import { useRef, useState } from "react";
import { useLocation } from "wouter";
import {
  Wallet,
  LogOut,
  Trash2,
  AlertTriangle,
  Shield,
  UserX,
  UserCheck,
  Crown,
  Lock,
  KeyRound,
  Mail,
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  Copy,
  Send,
  Sparkles,
} from "lucide-react";
import { GmailIcon } from "@/components/gmail-icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  useBaseSalary,
  useSales,
  useCurrentUser,
  useUsers,
  isAdmin,
  ADMIN_SEED,
  SUPPORT_EMAIL,
  type Sale,
} from "@/lib/store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { exportSalesToExcel, importSalesFromExcel } from "@/lib/excel-io";

export default function SettingsTab() {
  const [, setLocation] = useLocation();
  const [baseSalary, setBaseSalary] = useBaseSalary();
  const [sales, setSales] = useSales();
  const [currentUser, setCurrentUser] = useCurrentUser();
  const [users, setUsers] = useUsers();
  const { toast } = useToast();

  const [salaryInput, setSalaryInput] = useState(baseSalary.toString());
  const [pwUser, setPwUser] = useState<string | null>(null);
  const [newPw, setNewPw] = useState("");
  const [pendingDeleteUser, setPendingDeleteUser] = useState<string | null>(
    null,
  );

  const [importPreview, setImportPreview] = useState<{
    rows: Sale[];
    skipped: { row: number; reason: string }[];
    fileName: string;
  } | null>(null);
  const [importMode, setImportMode] = useState<"append" | "replace">("append");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const admin = isAdmin(currentUser, users);

  const handleSaveSalary = () => {
    const val = parseFloat(salaryInput);
    if (isNaN(val) || val < 0) {
      toast({ variant: "destructive", description: "قيمة الراتب غير صحيحة" });
      return;
    }
    setBaseSalary(val);
    toast({ description: "تم حفظ الراتب الأساسي" });
  };

  const handleResetSales = () => {
    setSales([]);
    toast({ description: "تم تصفير جميع المبيعات بنجاح" });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setLocation("/login");
  };

  const isProtected = (username: string) =>
    username === ADMIN_SEED.user || username === currentUser;

  const toggleUserStatus = (username: string) => {
    if (isProtected(username)) return;
    setUsers(
      users.map((u) =>
        u.user === username
          ? { ...u, status: u.status === "active" ? "frozen" : "active" }
          : u,
      ),
    );
    toast({ description: "تم تحديث حالة الحساب" });
  };

  const deleteUserConfirmed = () => {
    if (!pendingDeleteUser) return;
    if (isProtected(pendingDeleteUser)) {
      setPendingDeleteUser(null);
      return;
    }
    const username = pendingDeleteUser;
    setUsers(users.filter((u) => u.user !== username));
    toast({ description: `تم حذف المستخدم: ${username}` });
    setPendingDeleteUser(null);
  };

  const promoteUser = (username: string, role: "admin" | "user") => {
    setUsers(users.map((u) => (u.user === username ? { ...u, role } : u)));
    toast({
      description:
        role === "admin"
          ? "تم ترقية المستخدم إلى مسؤول"
          : "تم تحويل المستخدم إلى مستخدم عادي",
    });
  };

  const submitPasswordChange = () => {
    if (!pwUser || !newPw.trim()) return;
    setUsers(
      users.map((u) => (u.user === pwUser ? { ...u, pass: newPw } : u)),
    );
    setPwUser(null);
    setNewPw("");
    toast({ description: "تم تحديث كلمة المرور بنجاح" });
  };

  /* ===== Excel I/O ===== */

  const handleExport = () => {
    if (sales.length === 0) {
      toast({
        variant: "destructive",
        description: "لا توجد مبيعات لتصديرها",
      });
      return;
    }
    try {
      exportSalesToExcel(sales, currentUser);
      toast({
        description: `تم تصدير ${sales.length} عملية إلى ملف Excel`,
      });
    } catch (e) {
      toast({
        variant: "destructive",
        description: "فشل تصدير الملف",
      });
    }
  };

  const handleFilePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting same file
    if (!file) return;
    try {
      const result = await importSalesFromExcel(file);
      if (result.imported.length === 0) {
        toast({
          variant: "destructive",
          description: "لم يتم العثور على صفوف صالحة في الملف",
        });
        return;
      }
      setImportPreview({
        rows: result.imported,
        skipped: result.skipped,
        fileName: file.name,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        description: "فشلت قراءة الملف. تأكد أنه ملف Excel صالح.",
      });
    }
  };

  const confirmImport = () => {
    if (!importPreview) return;
    if (importMode === "replace") {
      setSales(importPreview.rows);
      toast({
        description: `تم استبدال البيانات بـ ${importPreview.rows.length} عملية`,
      });
    } else {
      setSales([...importPreview.rows, ...sales]);
      toast({
        description: `تمت إضافة ${importPreview.rows.length} عملية إلى المبيعات`,
      });
    }
    setImportPreview(null);
  };

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(SUPPORT_EMAIL);
      toast({ description: "تم نسخ البريد إلى الحافظة" });
    } catch {
      toast({ variant: "destructive", description: "فشل النسخ" });
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Base salary */}
      <div className="bg-card border border-card-border p-5 rounded-3xl shadow-sm space-y-4">
        <h3 className="text-lg font-bold flex items-center gap-2 text-foreground">
          <Wallet className="text-primary" />
          الراتب الأساسي
        </h3>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Input
              type="number"
              value={salaryInput}
              onChange={(e) => setSalaryInput(e.target.value)}
              className="h-12 rounded-xl bg-muted/30 ps-12"
              dir="ltr"
            />
            <div className="absolute inset-y-0 start-4 flex items-center pointer-events-none font-bold text-muted-foreground text-sm">
              د.ل
            </div>
          </div>
          <Button onClick={handleSaveSalary} className="h-12 px-6 rounded-xl font-bold">
            حفظ
          </Button>
        </div>
      </div>

      {/* Excel Import / Export */}
      <div className="bg-card border border-card-border p-5 rounded-3xl shadow-sm space-y-4">
        <h3 className="text-lg font-bold flex items-center gap-2 text-foreground">
          <FileSpreadsheet className="text-emerald-600" />
          استيراد وتصدير Excel
        </h3>
        <p className="text-xs text-muted-foreground leading-relaxed -mt-2">
          صدّر مبيعاتك إلى ملف Excel للنسخ الاحتياطي، أو استورد بيانات قديمة
          (مع تواريخها) من ملف موجود.
        </p>

        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={handleExport}
            className="h-12 rounded-xl font-bold gap-2 bg-emerald-600 hover:bg-emerald-700"
          >
            <Download size={16} />
            تصدير Excel
          </Button>
          <Button
            onClick={() => fileInputRef.current?.click()}
            variant="outline"
            className="h-12 rounded-xl font-bold gap-2 border-emerald-500/30 text-emerald-700 hover:bg-emerald-50"
          >
            <Upload size={16} />
            استيراد Excel
          </Button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          className="hidden"
          onChange={handleFilePick}
        />

        <div className="bg-muted/30 rounded-xl p-3 text-[11px] text-muted-foreground leading-relaxed">
          <p className="font-bold text-foreground mb-1">أعمدة الملف المتوقعة:</p>
          <p>
            التاريخ · الوقت · المنتج · الشركة · الكمية · العمولة الإجمالية
          </p>
        </div>
      </div>

      {/* Users management */}
      <div className="bg-card border border-card-border p-5 rounded-3xl shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold flex items-center gap-2 text-foreground">
            <Shield className="text-secondary" />
            إدارة المستخدمين
          </h3>
          {admin ? (
            <span className="text-[10px] font-black bg-secondary/20 text-secondary px-2 py-1 rounded-full flex items-center gap-1">
              <Crown size={11} /> صلاحيات مسؤول
            </span>
          ) : (
            <span className="text-[10px] font-bold bg-muted text-muted-foreground px-2 py-1 rounded-full flex items-center gap-1">
              <Lock size={11} /> مسؤول فقط
            </span>
          )}
        </div>

        {!admin ? (
          <div className="text-sm text-muted-foreground bg-muted/30 rounded-xl p-3 text-center">
            هذه الصفحة متاحة للمسؤولين فقط. لطلب أي تعديل يرجى مراجعة المسؤول.
          </div>
        ) : (
          <div className="space-y-3">
            {users.map((u) => {
              const isMe = u.user === currentUser;
              const isAdminUser = u.role === "admin";
              const isProtectedRow = isProtected(u.user);
              return (
                <div
                  key={u.user}
                  className="flex items-center justify-between p-3 rounded-xl bg-muted/30 gap-2"
                >
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="font-bold flex items-center gap-2 flex-wrap">
                      <span className="truncate">{u.user}</span>
                      {isMe && (
                        <span className="text-[10px] bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                          أنت
                        </span>
                      )}
                      {isAdminUser && (
                        <span className="text-[10px] bg-secondary/30 text-secondary px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Crown size={10} /> مسؤول
                        </span>
                      )}
                    </span>
                    <span
                      className={`text-xs ${u.status === "active" ? "text-green-600" : "text-destructive"}`}
                    >
                      {u.status === "active" ? "نشط" : "مجمد"}
                    </span>
                  </div>

                  <div className="flex gap-1.5 flex-shrink-0">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setPwUser(u.user)}
                      className="w-8 h-8 rounded-lg"
                      title="تغيير كلمة المرور"
                    >
                      <KeyRound size={14} />
                    </Button>

                    {!isProtectedRow && (
                      <>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() =>
                            promoteUser(
                              u.user,
                              isAdminUser ? "user" : "admin",
                            )
                          }
                          className="w-8 h-8 rounded-lg"
                          title={
                            isAdminUser ? "إلغاء صلاحيات المسؤول" : "ترقية إلى مسؤول"
                          }
                        >
                          <Crown
                            size={14}
                            className={isAdminUser ? "text-secondary" : ""}
                          />
                        </Button>

                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => toggleUserStatus(u.user)}
                          className="w-8 h-8 rounded-lg"
                          title={u.status === "active" ? "تجميد" : "إلغاء التجميد"}
                        >
                          {u.status === "active" ? (
                            <UserX size={14} />
                          ) : (
                            <UserCheck size={14} />
                          )}
                        </Button>

                        <Button
                          variant="destructive"
                          size="icon"
                          onClick={() => setPendingDeleteUser(u.user)}
                          className="w-8 h-8 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive hover:text-white"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Support contact — premium Gmail card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-white to-rose-50/40 dark:from-card dark:via-card dark:to-card border border-card-border rounded-3xl shadow-md">
        {/* Decorative ribbon */}
        <div className="absolute -top-12 -end-12 w-40 h-40 rounded-full bg-gradient-to-br from-primary/10 via-secondary/10 to-rose-200/30 blur-2xl pointer-events-none" />

        <div className="relative p-5 space-y-4">
          {/* Header */}
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-primary/80 text-secondary flex items-center justify-center shadow-md shadow-primary/20 flex-shrink-0">
              <Sparkles size={20} strokeWidth={2.4} />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-black text-foreground leading-tight">
                الدعم الفني والتواصل
              </h3>
              <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                فريق ARZAQ جاهز لخدمتك في أي وقت — لأي استفسار، اقتراح، أو
                مشكلة تقنية تواصل معنا مباشرة عبر البريد الرسمي.
              </p>
            </div>
          </div>

          {/* Gmail card */}
          <div className="relative bg-gradient-to-br from-card to-muted/30 border border-card-border rounded-2xl p-4 shadow-sm">
            {/* Brand stripe */}
            <div className="absolute top-0 inset-x-0 h-1 rounded-t-2xl bg-gradient-to-r from-[#4285F4] via-[#EA4335] via-[#FBBC05] to-[#34A853]" />

            <div className="flex items-center gap-3 pt-1">
              <div className="w-14 h-14 rounded-2xl bg-white dark:bg-white shadow-md ring-1 ring-black/5 flex items-center justify-center flex-shrink-0 p-2">
                <GmailIcon size={36} />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[9px] font-black tracking-[0.18em] text-muted-foreground uppercase">
                    Gmail
                  </span>
                  <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[9px] font-bold text-emerald-600">
                    متاح
                  </span>
                </div>
                <a
                  href={`mailto:${SUPPORT_EMAIL}`}
                  className="font-black text-sm text-foreground hover:text-primary transition-colors block truncate leading-tight"
                  dir="ltr"
                >
                  {SUPPORT_EMAIL}
                </a>
                <p className="text-[10px] text-muted-foreground font-bold mt-0.5">
                  البريد الرسمي للدعم
                </p>
              </div>
            </div>

            {/* Action buttons */}
            <div className="grid grid-cols-2 gap-2 mt-4">
              <a
                href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(
                  "استفسار من ARZAQ PRO ULTRA",
                )}`}
                className="h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2 hover:bg-primary/90 active:scale-[0.98] transition-all shadow-md shadow-primary/20"
              >
                <Send size={14} />
                مراسلة
              </a>
              <button
                onClick={copyEmail}
                className="h-11 rounded-xl bg-muted text-foreground font-bold text-sm flex items-center justify-center gap-2 hover:bg-muted/70 active:scale-[0.98] transition-all border border-card-border"
              >
                <Copy size={14} />
                نسخ البريد
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Password change dialog */}
      <AlertDialog
        open={pwUser !== null}
        onOpenChange={(open) => {
          if (!open) {
            setPwUser(null);
            setNewPw("");
          }
        }}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <KeyRound className="text-primary" />
              تغيير كلمة المرور
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              تعيين كلمة مرور جديدة للحساب: <b>{pwUser}</b>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-2">
            <Label className="text-sm mb-2 block">كلمة المرور الجديدة</Label>
            <Input
              type="text"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              placeholder="أدخل كلمة المرور الجديدة"
              className="h-12 rounded-xl bg-muted/30"
              dir="ltr"
            />
          </div>
          <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0 h-12 rounded-xl">
              إلغاء
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={submitPasswordChange}
              className="h-12 rounded-xl"
            >
              حفظ
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete user confirmation with name */}
      <AlertDialog
        open={pendingDeleteUser !== null}
        onOpenChange={(open) => !open && setPendingDeleteUser(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle /> حذف المستخدم
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right text-base">
              هل أنت متأكد من حذف الحساب التالي بشكل نهائي؟
            </AlertDialogDescription>
          </AlertDialogHeader>

          {pendingDeleteUser && (
            <div className="bg-destructive/5 border border-destructive/20 rounded-xl p-3 flex items-center gap-2">
              <UserX size={18} className="text-destructive flex-shrink-0" />
              <span className="font-black text-destructive">
                {pendingDeleteUser}
              </span>
            </div>
          )}

          <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0 h-12 rounded-xl">
              إلغاء
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={deleteUserConfirmed}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 h-12 rounded-xl"
            >
              نعم، احذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Import preview dialog */}
      <AlertDialog
        open={importPreview !== null}
        onOpenChange={(open) => !open && setImportPreview(null)}
      >
        <AlertDialogContent className="rounded-3xl max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-emerald-700">
              <CheckCircle2 /> تم تحليل الملف
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right text-sm">
              تم العثور على{" "}
              <b className="text-emerald-700">{importPreview?.rows.length}</b>{" "}
              صف صالح من الملف{" "}
              <span className="font-bold" dir="ltr">
                {importPreview?.fileName}
              </span>
              {importPreview && importPreview.skipped.length > 0 && (
                <>
                  {" "}— تم تخطي{" "}
                  <b className="text-rose-600">{importPreview.skipped.length}</b>{" "}
                  صف بسبب أخطاء
                </>
              )}
              .
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-2 py-2">
            <Label className="text-xs font-bold text-muted-foreground">
              طريقة الاستيراد
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setImportMode("append")}
                className={`p-3 rounded-xl border-2 text-start text-xs transition-all ${
                  importMode === "append"
                    ? "bg-emerald-50 border-emerald-500 text-emerald-900"
                    : "bg-muted/30 border-transparent text-muted-foreground"
                }`}
              >
                <div className="font-black mb-1">إضافة</div>
                <div>تُضاف للبيانات الحالية</div>
              </button>
              <button
                type="button"
                onClick={() => setImportMode("replace")}
                className={`p-3 rounded-xl border-2 text-start text-xs transition-all ${
                  importMode === "replace"
                    ? "bg-rose-50 border-rose-500 text-rose-900"
                    : "bg-muted/30 border-transparent text-muted-foreground"
                }`}
              >
                <div className="font-black mb-1">استبدال</div>
                <div>تحذف القديم وتضع الجديد</div>
              </button>
            </div>
          </div>

          {importPreview && importPreview.skipped.length > 0 && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-2 max-h-24 overflow-y-auto text-[10px] text-rose-800 font-bold space-y-0.5">
              {importPreview.skipped.slice(0, 8).map((s, i) => (
                <div key={i}>
                  • صف {s.row}: {s.reason}
                </div>
              ))}
              {importPreview.skipped.length > 8 && (
                <div>... و {importPreview.skipped.length - 8} أخرى</div>
              )}
            </div>
          )}

          <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0 h-12 rounded-xl">
              إلغاء
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmImport}
              className="h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700"
            >
              تأكيد الاستيراد
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="space-y-3 pt-4 border-t border-border">
        {admin && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full h-14 text-destructive border-destructive/30 hover:bg-destructive/10 hover:text-destructive rounded-xl gap-2 font-bold"
              >
                <Trash2 size={20} />
                تصفير جميع المبيعات
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="rounded-3xl">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle /> تحذير هام
                </AlertDialogTitle>
                <AlertDialogDescription className="text-base text-right">
                  هل أنت متأكد من مسح جميع المبيعات المسجلة لحسابك؟ لن تتمكن من
                  استعادتها أبداً وسيتم تصفير عمولاتك للشهر الحالي.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
                <AlertDialogCancel className="mt-0 h-12 rounded-xl font-bold">
                  إلغاء
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleResetSales}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90 h-12 rounded-xl font-bold"
                >
                  تأكيد التصفير
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        <Button
          variant="secondary"
          className="w-full h-14 rounded-xl gap-2 font-bold bg-muted text-foreground hover:bg-muted/80"
          onClick={handleLogout}
        >
          <LogOut size={20} className="rotate-180" />
          تسجيل الخروج
        </Button>
      </div>

      <div className="text-center pb-6">
        <p className="text-xs text-muted-foreground opacity-50 font-mono tracking-widest mt-8">
          ARZAQ PRO ULTRA v1.1
        </p>
      </div>
    </div>
  );
}
