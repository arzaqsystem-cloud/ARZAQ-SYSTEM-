import { useState, useMemo, useEffect, memo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Wallet,
  Target,
  CalendarDays,
  Receipt,
  Building2,
  Package,
  Clock,
  Check,
  ChevronsUpDown,
  Hash,
  Minus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useProducts, useSales, useBaseSalary } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useVisibilityClock, formatTime12 } from "@/lib/visibility-clock";

/** Self-contained live clock so the parent doesn't re-render every second. */
const LiveClock = memo(function LiveClock() {
  const now = useVisibilityClock(1000);
  return (
    <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-4 rounded-2xl shadow-md flex items-center justify-between">
      <div className="flex flex-col">
        <span className="text-xs font-bold opacity-80">اليوم</span>
        <span className="font-bold text-sm mt-0.5">
          {format(now, "EEEE، d MMMM yyyy", { locale: ar })}
        </span>
      </div>
      <div className="flex items-center gap-2 bg-white/15 px-3 py-1.5 rounded-xl backdrop-blur-sm">
        <Clock size={16} />
        <span className="font-black tabular-nums tracking-wider text-sm min-w-[100px] text-center">
          {formatTime12(now)}
        </span>
      </div>
    </div>
  );
});

const StatCard = memo(function StatCard({
  title,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  title: string;
  value: number;
  sub?: string;
  icon: any;
  accent: "primary" | "secondary" | "salary";
}) {
  const accentMap = {
    primary: "from-primary/15 to-primary/5 text-primary",
    secondary: "from-secondary/20 to-secondary/5 text-secondary",
    salary: "from-emerald-500/15 to-emerald-500/5 text-emerald-600",
  } as const;
  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br ${accentMap[accent]} bg-card border border-card-border p-4 rounded-2xl shadow-sm`}
    >
      <div className="flex items-start justify-between gap-2 relative z-10">
        <div className="min-w-0 flex-1">
          <p className="text-muted-foreground text-xs font-bold mb-1.5">
            {title}
          </p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-foreground tabular-nums">
              {value.toFixed(2)}
            </span>
            <span className="text-[10px] font-bold text-muted-foreground">
              د.ل
            </span>
          </div>
          {sub && (
            <p className="text-[10px] text-muted-foreground mt-1 font-medium">
              {sub}
            </p>
          )}
        </div>
        <div className="p-2 rounded-xl bg-background/60">
          <Icon className="w-5 h-5" strokeWidth={2.2} />
        </div>
      </div>
    </div>
  );
});

export default function SalesTab() {
  const [products] = useProducts();
  const [sales, setSales] = useSales();
  const [baseSalary] = useBaseSalary();
  const { toast } = useToast();

  const [selectedCompany, setSelectedCompany] = useState<string>("");
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  const [productPickerOpen, setProductPickerOpen] = useState(false);
  const [priceStr, setPriceStr] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [isAnimating, setIsAnimating] = useState(false);

  const companies = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => set.add(p.company));
    return Array.from(set);
  }, [products]);

  const productsForCompany = useMemo(
    () => products.filter((p) => p.company === selectedCompany),
    [products, selectedCompany],
  );

  const selectedProduct = products.find((p) => p.id === selectedProductId);

  const previewCommission = useMemo(() => {
    if (!selectedProduct) return 0;
    if (selectedProduct.type === "fixed") {
      return selectedProduct.comm * quantity;
    }
    const price = parseFloat(priceStr) || 0;
    return price * quantity * (selectedProduct.comm / 100);
  }, [selectedProduct, priceStr, quantity]);

  const handleAddSale = () => {
    if (!selectedCompany) {
      toast({ variant: "destructive", description: "الرجاء اختيار الشركة" });
      return;
    }
    if (!selectedProductId) {
      toast({ variant: "destructive", description: "الرجاء اختيار الصنف" });
      return;
    }

    const product = products.find((p) => p.id === selectedProductId);
    if (!product) return;

    if (quantity < 1) {
      toast({
        variant: "destructive",
        description: "الكمية يجب أن تكون 1 أو أكثر",
      });
      return;
    }

    let commission = 0;
    const price = parseFloat(priceStr) || 0;

    if (product.type === "fixed") {
      commission = product.comm * quantity;
    } else {
      if (!price) {
        toast({
          variant: "destructive",
          description: "الرجاء إدخال السعر لحساب نسبة العمولة",
        });
        return;
      }
      commission = price * quantity * (product.comm / 100);
    }

    const newSale = {
      id: crypto.randomUUID(),
      productName: product.name,
      company: product.company,
      commission,
      quantity,
      date: new Date().toISOString(),
    };

    setSales([newSale, ...sales]);
    setSelectedProductId("");
    setPriceStr("");
    setQuantity(1);

    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 600);

    toast({
      title: "تمت الإضافة بنجاح",
      description: `${product.name} (${product.company}) × ${quantity} — ${commission.toFixed(2)} د.ل`,
      className: "bg-primary text-primary-foreground border-none",
    });
  };

  // Stable date keys — recompute only once a minute, not every second.
  const [dateKeys, setDateKeys] = useState(() => {
    const d = new Date();
    return { day: format(d, "yyyy-MM-dd"), month: format(d, "yyyy-MM") };
  });
  useEffect(() => {
    const refresh = () => {
      const d = new Date();
      const day = format(d, "yyyy-MM-dd");
      const month = format(d, "yyyy-MM");
      setDateKeys((prev) =>
        prev.day === day && prev.month === month ? prev : { day, month },
      );
    };
    let id: number | null = null;
    const start = () => {
      if (id !== null) return;
      refresh();
      id = window.setInterval(refresh, 60_000);
    };
    const stop = () => {
      if (id !== null) {
        window.clearInterval(id);
        id = null;
      }
    };
    const onVis = () =>
      document.visibilityState === "visible" ? start() : stop();
    if (document.visibilityState === "visible") start();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  const stats = useMemo(() => {
    let todaySalesCount = 0;
    let monthSalesCount = 0;
    let todayComm = 0;
    let monthComm = 0;

    sales.forEach((sale) => {
      const saleDate = new Date(sale.date);
      const saleDay = format(saleDate, "yyyy-MM-dd");
      const saleMonth = format(saleDate, "yyyy-MM");

      if (saleDay === dateKeys.day) {
        todayComm += sale.commission;
        todaySalesCount += 1;
      }
      if (saleMonth === dateKeys.month) {
        monthComm += sale.commission;
        monthSalesCount += 1;
      }
    });

    return {
      todayComm,
      monthComm,
      todaySalesCount,
      monthSalesCount,
      projected: monthComm + baseSalary,
    };
  }, [sales, baseSalary, dateKeys]);

  return (
    <div className="p-4 space-y-5">
      <LiveClock />

      <div className="bg-card border border-card-border p-5 rounded-3xl shadow-md">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Receipt className="text-primary" size={20} />
          تسجيل بيع جديد
        </h2>

        <div className="space-y-4">
          {/* Company picker */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5 text-sm">
              <Building2 size={14} className="text-muted-foreground" />
              الشركة
            </Label>
            <Select
              value={selectedCompany}
              onValueChange={(v) => {
                setSelectedCompany(v);
                setSelectedProductId("");
                setPriceStr("");
                setQuantity(1);
              }}
            >
              <SelectTrigger className="h-13 rounded-xl text-base bg-muted/30">
                <SelectValue placeholder="اختر الشركة" />
              </SelectTrigger>
              <SelectContent>
                {companies.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground text-sm">
                    لا توجد شركات بعد
                  </div>
                ) : (
                  companies.map((c) => (
                    <SelectItem key={c} value={c} className="text-base py-3">
                      <span className="font-bold">{c}</span>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Searchable product picker */}
          <AnimatePresence initial={false}>
            {selectedCompany && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-2 overflow-hidden"
              >
                <Label className="flex items-center gap-1.5 text-sm">
                  <Package size={14} className="text-muted-foreground" />
                  الصنف
                </Label>
                <Popover
                  open={productPickerOpen}
                  onOpenChange={setProductPickerOpen}
                >
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      className="w-full h-13 rounded-xl bg-muted/30 justify-between text-base font-normal hover:bg-muted/40"
                    >
                      {selectedProduct ? (
                        <span className="flex items-center gap-2 font-bold">
                          {selectedProduct.name}
                          <span className="text-[11px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-md">
                            {selectedProduct.type === "fixed"
                              ? `${selectedProduct.comm} د.ل`
                              : `${selectedProduct.comm}٪`}
                          </span>
                        </span>
                      ) : (
                        <span className="text-muted-foreground">
                          اختر الصنف المباع
                        </span>
                      )}
                      <ChevronsUpDown className="h-4 w-4 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent
                    className="w-[--radix-popover-trigger-width] p-0 rounded-xl"
                    align="start"
                  >
                    <Command
                      filter={(value, search) => {
                        if (!search) return 1;
                        return value
                          .toLowerCase()
                          .includes(search.toLowerCase())
                          ? 1
                          : 0;
                      }}
                    >
                      <CommandInput
                        placeholder="ابحث عن صنف..."
                        className="h-11 text-sm"
                      />
                      <CommandList className="max-h-[280px]">
                        <CommandEmpty>لا توجد نتائج</CommandEmpty>
                        <CommandGroup>
                          {productsForCompany.map((p) => (
                            <CommandItem
                              key={p.id}
                              value={p.name}
                              onSelect={() => {
                                setSelectedProductId(p.id);
                                setProductPickerOpen(false);
                              }}
                              className="cursor-pointer py-2.5"
                            >
                              <Check
                                className={cn(
                                  "ms-1 h-4 w-4",
                                  selectedProductId === p.id
                                    ? "opacity-100"
                                    : "opacity-0",
                                )}
                              />
                              <span className="font-bold flex-1">{p.name}</span>
                              <span className="text-[11px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-md">
                                {p.type === "fixed"
                                  ? `${p.comm} د.ل`
                                  : `${p.comm}٪`}
                              </span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quantity + Price (price only for percent) */}
          <AnimatePresence initial={false}>
            {selectedProduct && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden space-y-3"
              >
                <div className="grid grid-cols-2 gap-3">
                  {/* Quantity */}
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5 text-sm">
                      <Hash size={13} className="text-muted-foreground" />
                      الكمية
                    </Label>
                    <div className="flex items-center bg-muted/30 rounded-xl h-13 overflow-hidden border border-input">
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="w-12 h-full flex items-center justify-center text-lg font-bold hover:bg-muted/60 active:scale-95 transition-all"
                        aria-label="تنقيص"
                      >
                        <Minus size={16} />
                      </button>
                      <input
                        type="number"
                        inputMode="numeric"
                        min={1}
                        value={quantity}
                        onChange={(e) => {
                          const v = parseInt(e.target.value, 10);
                          setQuantity(isNaN(v) || v < 1 ? 1 : v);
                        }}
                        className="flex-1 bg-transparent text-center font-black text-lg tabular-nums outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => q + 1)}
                        className="w-12 h-full flex items-center justify-center text-lg font-bold hover:bg-muted/60 active:scale-95 transition-all"
                        aria-label="زيادة"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Price for percent — fixed slot for layout balance otherwise */}
                  {selectedProduct.type === "percent" ? (
                    <div className="space-y-2">
                      <Label className="text-sm">سعر القطعة</Label>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="أدخل السعر"
                          value={priceStr}
                          onChange={(e) => setPriceStr(e.target.value)}
                          className="h-13 rounded-xl text-base ps-12 bg-muted/30"
                          dir="ltr"
                        />
                        <div className="absolute inset-y-0 start-4 flex items-center pointer-events-none font-bold text-muted-foreground text-sm">
                          د.ل
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label className="text-sm text-transparent select-none">
                        .
                      </Label>
                      <div className="h-13 rounded-xl bg-muted/15 border border-dashed border-border flex items-center justify-center text-[11px] text-muted-foreground font-bold px-2 text-center">
                        عمولة ثابتة
                      </div>
                    </div>
                  )}
                </div>

                {/* Live preview */}
                {previewCommission > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-primary/10 border border-primary/20 text-primary rounded-xl px-3 py-2 flex items-center justify-between text-sm"
                  >
                    <span className="font-bold">العمولة المتوقعة</span>
                    <span className="font-black tabular-nums">
                      {previewCommission.toFixed(2)}{" "}
                      <span className="text-[10px]">د.ل</span>
                    </span>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <Button
            className={`w-full h-14 text-lg font-bold rounded-xl mt-2 relative overflow-hidden transition-colors ${isAnimating ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
            onClick={handleAddSale}
          >
            <span className="relative z-10 flex items-center gap-2">
              <Plus strokeWidth={3} /> إضافة البيع
            </span>
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          title="مبيعات اليوم"
          value={stats.todayComm}
          sub={`${stats.todaySalesCount} عملية`}
          icon={Target}
          accent="primary"
        />
        <StatCard
          title="مبيعات الشهر"
          value={stats.monthComm}
          sub={`${stats.monthSalesCount} عملية`}
          icon={CalendarDays}
          accent="secondary"
        />
        <div className="col-span-2">
          <StatCard
            title={`الراتب المتوقع (الأساسي ${baseSalary} د.ل + العمولات)`}
            value={stats.projected}
            icon={Wallet}
            accent="salary"
          />
        </div>
      </div>
    </div>
  );
}
