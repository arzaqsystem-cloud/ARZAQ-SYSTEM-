type Props = { size?: number; className?: string };

/**
 * Official Gmail multicolor envelope mark (M-shape) — vector, no external deps.
 * Renders crisp at any size and ships with proper drop-shadow for an elegant feel.
 */
export function GmailIcon({ size = 24, className }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Gmail"
    >
      <path
        fill="#4285F4"
        d="M40 12.661v22.84A2.5 2.5 0 0 1 37.5 38H34V19.875L24 27.25l-10-7.375V38h-3.5A2.5 2.5 0 0 1 8 35.5V12.66l2-1.476 14 10.327 14-10.327 2 1.476Z"
      />
      <path
        fill="#34A853"
        d="M34 38h3.5a2.5 2.5 0 0 0 2.5-2.5V12.66L34 17.083V38Z"
      />
      <path
        fill="#FBBC05"
        d="M14 38v-18.125L8 15.45V35.5A2.5 2.5 0 0 0 10.5 38H14Z"
      />
      <path
        fill="#EA4335"
        d="M14 19.875 24 27.25l10-7.375V12.66l-10 7.375L14 12.66v7.215Z"
      />
      <path
        fill="#C5221F"
        d="M8 12.66v2.79l6 4.425V12.66l-1-.738a2.5 2.5 0 0 0-2.95-.014L8 12.66Zm32 0v2.79l-6 4.425V12.66l1-.738a2.5 2.5 0 0 1 2.95-.014L40 12.66Z"
      />
    </svg>
  );
}
