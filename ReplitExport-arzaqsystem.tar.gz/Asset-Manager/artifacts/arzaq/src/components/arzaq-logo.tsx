type Props = {
  size?: number;
  className?: string;
  variant?: "light" | "dark";
};

export function ArzaqMark({ size = 48, className = "", variant = "light" }: Props) {
  const bg = variant === "light" ? "#ffffff" : "#0d3b2e";
  const fg = variant === "light" ? "#0d3b2e" : "#f4d27a";
  const accent = variant === "light" ? "#d4a64a" : "#d4a64a";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="ARZAQ"
    >
      <rect width="64" height="64" rx="16" fill={bg} />
      <path
        d="M14 46 L26 18 L38 46"
        stroke={fg}
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M19 36 L33 36"
        stroke={fg}
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="46" cy="20" r="5" fill={accent} />
      <path
        d="M44 46 L52 30"
        stroke={accent}
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ArzaqLogoFull({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <ArzaqMark size={56} />
      <div className="flex flex-col leading-none">
        <span className="font-black tracking-[0.18em] text-3xl">ARZAQ</span>
        <span className="text-[10px] font-bold tracking-[0.45em] mt-1 opacity-80">
          PRO ULTRA
        </span>
      </div>
    </div>
  );
}
